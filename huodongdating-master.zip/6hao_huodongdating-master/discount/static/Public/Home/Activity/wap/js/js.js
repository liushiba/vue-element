// 弹框显示
function show(index){
  $('#modal'+index).show().siblings('.modal').hide();
};
$(function(){
  // 关闭弹窗
  $(".modal .close").on('click', function(){
    $(".modal").hide();
  });
  // 导航菜单
  $("#nav-more").on('click', function(e){
    $(this).find('nav').toggle();
    e.stopPropagation();
  });
  // 导航菜单-隐藏
  $('body').on('click', function(){
    $("#nav-more nav").hide();
  });
});