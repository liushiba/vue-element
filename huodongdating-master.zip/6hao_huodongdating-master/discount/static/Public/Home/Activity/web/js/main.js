
$('.layui-layer-close').click(function(event) {
	$(this).parents('.modal').hide(100);
});
$('.modal').click(function(event) {
  $(this).hide(100);
});
$('.modal_wrap').click(function(event) {
   event.stopPropagation();
});

function show(index){
	var height = $('#querycon'+index).height();
	var width = $('#querycon'+index).width();
	$('#querycon'+index).css({'margin-top': -height/2, 'margin-left': -width/2});
	$('#querycon'+index).show(300).siblings('.modal').hide();
};

function notice(){
  var demo = document.getElementById("demo");
  var demo1 = document.getElementById("demo1");
  var demo2 = document.getElementById("demo2");
  demo2.innerHTML=document.getElementById("demo1").innerHTML;
  function Marquee(){
  if(demo.scrollLeft-demo2.offsetWidth>=0){
   demo.scrollLeft-=demo1.offsetWidth;
  }
  else{
   demo.scrollLeft++;
  }
  }
  var myvar=setInterval(Marquee,60);
  demo.onmouseout=function (){myvar=setInterval(Marquee,60);}
  demo.onmouseover=function(){clearInterval(myvar);}
}
notice();

function notice1(){
  var demo = document.getElementById("demo3");
  var demo1 = document.getElementById("demo4");
  var demo2 = document.getElementById("demo5");
  demo2.innerHTML=document.getElementById("demo4").innerHTML;
  function Marquee(){
  if(demo.scrollLeft-demo2.offsetWidth>=0){
   demo.scrollLeft-=demo1.offsetWidth;
  }
  else{
   demo.scrollLeft++;
  }
  }
  var myvar=setInterval(Marquee,60);
  demo.onmouseout=function (){myvar=setInterval(Marquee,60);}
  demo.onmouseover=function(){clearInterval(myvar);}
}
notice1();