# -*- coding: utf-8 -*-
from django.shortcuts import render, redirect
from rebate.models import Items, RecNew, RecMine, RecPass, ItemInfo, Rec, News
from django.views.generic import View
from django.http.response import JsonResponse, HttpResponse
from django.http import HttpResponseRedirect
from django.utils import timezone
from datetime import timedelta
from django.db.models import Q
from django.contrib import messages
import datetime
import pytz
from PIL import Image, ImageDraw, ImageFont
from django.utils.six import BytesIO

class IndexView(View):
    def get(self, request):
        items = Items.objects.filter(is_show=True)
        sets = []
        for item in items:
            iteminfos = ItemInfo.objects.filter(for_item=item)
            infostr = []
            for iteminfo in iteminfos:
                infostr.append((iteminfo.text))
            sets.append({
                "Url": item.jump_link,
                "ClassRemark": '../rebate/media/' + str(item.pic),
                "T_ProClassName": item.name,
                "T_ProClassID": item.id,
                "T_ProClassKey": item.info,
                "T_ProClassDes": item.serial,
                "IsXz": '1' if item.ipc else '0',
                "IsBlock": '1' if item.is_show else '0',
                "IsDayXz": '1' if item.dailyc else '0',
                "DayXzMessage": item.c_msg,
                "IsOpen": '1' if item.is_active else '0',
                "IsTimeXz": '1' if item.timec else '0',
                "WapImage": '',
                "DetailUrl": item.detail_link,
                "IsOrderXz": '1' if item.once_odn else '0',
                "IsCheckState": '1' if item.verifyc else '0',
                "InfoList": infostr,
                "jump_link": item.jump_link if item.jump_link else None
            })
        infos = News.objects.all()
        return render(request, 'index.html', {'sets': sets, 'infos': infos})


class IndexWapView(View):
    def get(self, request):
        items = Items.objects.filter(is_show=True)
        sets = []
        for item in items:
            iteminfos = ItemInfo.objects.filter(for_item=item)
            infostr = []
            for iteminfo in iteminfos:
                infostr.append((iteminfo.text))
            sets.append({
                "Url": item.jump_link,
                "ClassRemark": '../rebate/media/' + str(item.pic),
                "T_ProClassName": item.name,
                "T_ProClassID": item.id,
                "T_ProClassKey": item.info,
                "T_ProClassDes": item.serial,
                "IsXz": '1' if item.ipc else '0',
                "IsBlock": '1' if item.is_show else '0',
                "IsDayXz": '1' if item.dailyc else '0',
                "DayXzMessage": item.c_msg,
                "IsOpen": '1' if item.is_active else '0',
                "IsTimeXz": '1' if item.timec else '0',
                "WapImage": '',
                "DetailUrl": item.detail_link,
                "IsOrderXz": '1' if item.once_odn else '0',
                "IsCheckState": '1' if item.verifyc else '0',
                "InfoList": infostr,
                "jump_link": item.jump_link if item.jump_link else None
            })
        infos = News.objects.all()
        return render(request, 'indexwap.html', {'sets': sets, 'infos': infos})


class IndexWapDetailView(View):
    def get(self, request):
        act_id = request.GET['act_id']
        items = Items.objects.filter(is_show=True).filter(id=act_id)
        sets = []
        for item in items:
            iteminfos = ItemInfo.objects.filter(for_item=item)
            infostr = []
            for iteminfo in iteminfos:
                infostr.append((iteminfo.text))
            sets.append({
                "Url": item.jump_link,
                "ClassRemark": '../rebate/media/' + str(item.pic),
                "T_ProClassName": item.name,
                "T_ProClassID": item.id,
                "T_ProClassKey": item.info,
                "T_ProClassDes": item.serial,
                "IsXz": '1' if item.ipc else '0',
                "IsBlock": '1' if item.is_show else '0',
                "IsDayXz": '1' if item.dailyc else '0',
                "DayXzMessage": item.c_msg,
                "IsOpen": '1' if item.is_active else '0',
                "IsTimeXz": '1' if item.timec else '0',
                "WapImage": '',
                "DetailUrl": item.detail_link,
                "IsOrderXz": '1' if item.once_odn else '0',
                "IsCheckState": '1' if item.verifyc else '0',
                "InfoList": infostr,
                "jump_link": item.jump_link if item.jump_link else None
            })
        infos = News.objects.all()
        item_name = Items.objects.filter(is_show=True)
        return render(request, 'indexwapdetail.html', {'sets': sets, 'infos': infos, 'item_name': item_name})


class ItemView(View):
    def post(self, request):
        items = Items.objects.filter(is_show=True).order_by('-serial')
        sets = []
        for item in items:
            iteminfos = ItemInfo.objects.filter(for_item=item)
            infostr = ''
            for iteminfo in iteminfos:
                infostr += (iteminfo.text + '|'+str(iteminfo.way)+',')
            sets.append({
                "Url": item.jump_link,
                "ClassRemark": '../rebate/media/'+str(item.pic),
                "T_ProClassName": item.name,
                "T_ProClassID": item.id,
                "T_ProClassKey": item.info,
                "T_ProClassDes": item.serial,
                "IsXz": '1' if item.ipc else '0',
                "IsBlock": '1' if item.is_show else '0',
                "IsDayXz": '1' if item.dailyc else '0',
                "DayXzMessage": item.c_msg,
                "IsOpen": '1' if item.is_active else '0',
                "IsTimeXz": '1' if item.timec else '0',
                "WapImage": '',
                "DetailUrl": item.detail_link,
                "IsOrderXz": '1' if item.once_odn else '0',
                "IsCheckState": '1' if item.verifyc else '0',
                "InfoList": infostr
            })
        return HttpResponse(str(sets))


class RecView(View):
    def post(self, request):
        verify = request.POST['verify']
        verifycode = request.session['verifycode']
        if verify.lower() != verifycode.lower():
            return JsonResponse({"status": 1, "msg": "验证码不正确"})

        act_id = request.GET.get('act_id')
        if 'HTTP_X_FORWARDED_FOR' in request.META.values():
            ip = request.META['HTTP_X_FORWARDED_FOR']
        else:
            ip = request.META['REMOTE_ADDR']
        username = request.POST['account']

        if not username:
            return JsonResponse({"status": 1, "msg": "用户名不存在"})

        # 获取申请的活动信息
        act_id = int(act_id)
        item = Items.objects.get(id=act_id)
        # 无需在线申请
        if not item.is_online:
            return JsonResponse({"status": 1, "msg": "无需在线申请,系统统一派送"})
        # 活动是否开启
        if not item.is_active:
            return JsonResponse({"status": 1, "msg": "活动未开启"})

        # ip限制
        if item.ipc:
            recs = Rec.objects.filter(activity=item)
            if recs.exists():
                for rec in recs:
                    if rec.ip == ip:
                        return JsonResponse({"status": 1, "msg": "该IP已申请,请勿重复提交"})

        # 是否时间正确
        if item.timec:
            now = datetime.datetime.utcnow().replace(tzinfo=pytz.timezone('UTC'))
            if not (item.start_time <= now <= item.end_time):
                return JsonResponse({"status": 1, "msg": "不是申请时间,详细请点击“查看详细”"})

        # 活动申请每日限制
        if item.dailyc:
            tod = datetime.datetime.utcnow().replace(tzinfo=pytz.timezone('UTC'))
            tom = datetime.datetime.utcnow().replace(tzinfo=pytz.timezone('UTC')) + datetime.timedelta(days=1)
            nums = Rec.objects.filter(name=username).filter(activity=item).filter(apply_time__gte=tod).filter(apply_time__lt=tom).count()
            if nums >= item.c_times:
                return JsonResponse({"status": 1, "msg": "达到每日提交的上限"})

        # 审核中无法提交
        if item.verifyc:
            recs = Rec.objects.filter(name=username).filter(activity=item).filter(Q(verify=0) | Q(verify=1))
            if recs.exists():
                return JsonResponse({"status": 1, "msg": "您的申请正在审核中，请勿重复提交....."})

        info = '会员账号: ◆ %s' % username + '+'
        iteminfos = item.iteminfo_set.all()
        i = 1
        for iteminfo in iteminfos:
            info += iteminfo.text + ': ◆ ' +request.POST.get('data[%s]' % str(i), '') + '+'
            i += 1
        try:
            item = Items.objects.filter(id=int(act_id)).first()
            Rec.objects.create(activity=item, name=username, info_post=info, ip=ip)
        except Exception as e:
            print(e)
            return JsonResponse({"status": 1, "msg": "提交失败,请联系客服人员"})

        return JsonResponse({"status": 0, "msg": "提交成功"})


class RecWapView(View):
    def post(self, request):
        verify = request.POST['verify']
        verifycode = request.session['verifycode']
        if verify.lower() != verifycode.lower():
            return JsonResponse({"status": 1, "msg": "验证码不正确"})
        if 'HTTP_X_FORWARDED_FOR' in request.META.values():
            ip = request.META['HTTP_X_FORWARDED_FOR']
        else:
            ip = request.META['REMOTE_ADDR']
        username = request.POST['account']
        act_id = request.POST['activity_id']

        if not username:
            return JsonResponse({"status": 1, "msg": "用户名不存在"})

        # 获取申请的活动信息
        item = Items.objects.get(id=act_id)
        # 无需在线申请
        if not item.is_online:
            return JsonResponse({"status": 1, "msg": "无需在线申请,系统统一派送"})
        # 活动是否开启
        if not item.is_active:
            return JsonResponse({"status": 1, "msg": "活动未开启"})

        # ip限制
        if item.ipc:
            recs = Rec.objects.filter(activity=item)
            if recs.exists():
                for rec in recs:
                    if rec.ip == ip:
                        return JsonResponse({"status": 1, "msg": "该IP已申请,请勿重复提交"})

        # 是否时间正确
        if item.timec:
            now = datetime.datetime.utcnow().replace(tzinfo=pytz.timezone('UTC'))
            if not (item.start_time <= now <= item.end_time):
                return JsonResponse({"status": 1, "msg": "不是申请时间,详细请点击“查看详细”"})

        # 活动申请每日限制
        if item.dailyc:
            tod = datetime.datetime.utcnow().replace(tzinfo=pytz.timezone('UTC'))
            tom = datetime.datetime.utcnow().replace(tzinfo=pytz.timezone('UTC')) + datetime.timedelta(days=1)
            nums = Rec.objects.filter(name=username).filter(activity=item).filter(apply_time__gte=tod).filter(apply_time__lt=tom).count()
            if nums >= item.c_times:
                return JsonResponse({"status": 1, "msg": "达到每日提交的上限"})

        # 审核中无法提交
        if item.verifyc:
            recs = Rec.objects.filter(name=username).filter(activity=item).filter(Q(verify=0) | Q(verify=1))
            if recs.exists():
                return JsonResponse({"status": 1, "msg": "您的申请正在审核中，请勿重复提交....."})

        info = '会员账号: ◆ %s' % username + '+'
        iteminfos = item.iteminfo_set.all()
        i = 1
        for iteminfo in iteminfos:
            info += iteminfo.text + ': ◆ ' +request.POST.get('data[%s]' % str(i), '') + '+'
            i += 1
        try:
            item = Items.objects.filter(id=int(act_id)).first()
            Rec.objects.create(activity=item, name=username, info_post=info, ip=ip)
        except Exception as e:
            print(e)
            return JsonResponse({"status": 1, "msg": "提交失败,请联系客服人员"})
        return JsonResponse({"status": 0, "msg": "提交成功"})


class MineView(View):
    def post(self, request):
        username = request.POST['account']
        act_id = request.POST['activity']
        page = request.POST['page']
        item = Items.objects.get(id=act_id)
        recs = Rec.objects.filter(activity=item).filter(name=username).order_by('-apply_time')
        if recs.exists():
            data = ""
            status_choices = {
                0: '待处理',
                1: '审核中',
                2: '已派发',
                3: '未通过'
            }
            check_news = {
                0: "等待处理",
                1: "正在审核中",
                2: "恭喜您，您的彩金已经派送到您的账号了哦，请您登录查收啦 双击查看原图愿亲每日财运亨通，盈利多多哟~~！",
                3: "尊敬的会员您好，由于您没有达到优惠活动的要求，因此您的申请无法通过， 感谢您对“澳门金沙国际.9937com ”的支持与厚爱~请您关注其他优惠活动，谢谢！"
            }
            for rec in recs:
                data += """<tr>
                            <td>%s
                            <td>%s
                            <td class=\"red\">%s
                            <td><a href=\"\">点击查看<p class=\"tip\"><span>%s
                            """ % (rec.name, (rec.apply_time+datetime.timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S'), status_choices[int(rec.verify)], check_news[int(rec.verify)])
            return JsonResponse({"status": 1, "list": data, "page": "<a href=\"javascript:;\" onclick=\"schedule(1)\">1"})
        else:
            return JsonResponse({"status": "1", "list": r"<td colspan='4'>暂无记录", "page": None})


class MineWapView(View):
    def post(self, request):
        username = request.POST['account']
        act_id = request.POST['activity']
        item = Items.objects.get(id=act_id)
        recs = Rec.objects.filter(activity=item).filter(name=username)
        if recs.exists():
            data = ""
            status_choices = {
                0: '待处理',
                1: '审核中',
                2: '已派发',
                3: '未通过'
            }
            check_news = {
                0: "等待处理",
                1: "正在审核中",
                2: "管理员答复：恭喜您，您的彩金已经派送到您的账号了哦，请您登录查收啦 双击查看原图愿亲每日财运亨通，盈利多多哟~~！",
                3: "管理员答复：尊敬的会员您好，由于您没有达到优惠活动的要求，因此您的申请无法通过， 感谢您对“澳门金沙国际.9937com ”的支持与厚爱~请您关注其他优惠活动，谢谢！"
            }

            for rec in recs:
                data += """<div class=\"item\">
                            <p>申请日期：%s
                            <p>审核结果：<span class=\"red\">%s
                            <p>%s
                            """ % ((rec.apply_time+datetime.timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S'), status_choices[int(rec.verify)], check_news[int(rec.verify)])
            return JsonResponse({"status": 1, "list": data, "activity_title": "%s" % item.name})
        else:
            return JsonResponse({"status": "1", "list": "<div class=\"item\">暂无结果", "activity_title": "%s" % item.name})


class QueryView(View):
    def post(self, request):
        recs = Rec.objects.filter(verify=2).filter(answer__isnull=False).filter(lock=False).order_by('-verify_time')[0:49]
        data = []
        for rec in recs:
            data.append({
                "T_ProductName": rec.name[0:-3]+'***',
                "T_ProClassName": rec.activity.name,
            })
        return HttpResponse(str(data))


class SkipView(View):
    def get(self, request):
        params = request.GET['name']
        rec_object = Rec.objects.get(id=int(params))
        if not rec_object.lock:
            rec_object.lock = 1
            rec_object.verify = 1
            rec_object.save()
            return HttpResponseRedirect('/rebate/admin/rebate/recmine/')
        else:
            messages.add_message(request, messages.WARNING, '该申请已交由他人处理！')
            return redirect('/rebate/admin/rebate/recnew/')


class PassView(View):
    def get(self, request):
        params = request.GET['name']
        rec_object = Rec.objects.get(id=int(params))
        if (rec_object.verify == 2 or rec_object.verify == 3):
            rec_object.lock = 0
            rec_object.verify_time = datetime.datetime.now()
            rec_object.who = request.user
            rec_object.save()
            return HttpResponseRedirect('/rebate/admin/rebate/recmine/')
        else:
            messages.add_message(request, messages.WARNING, '请完善相应的处理信息！')
            return redirect('/rebate/admin/rebate/recmine/')


class VerifyCodeView(View):
    def get(self, request):
        # 引入随机函数模块
        import random
        # 定义变量，用于画面的背景色、宽、高
        bgcolor = (random.randrange(20, 100), random.randrange(
            20, 100), 255)
        width = 100
        height = 35
        # 创建画面对象
        im = Image.new('RGB', (width, height), bgcolor)
        # 创建画笔对象
        draw = ImageDraw.Draw(im)
        # 调用画笔的point()函数绘制噪点
        for i in range(0, 100):
            xy = (random.randrange(0, width), random.randrange(0, height))
            fill = (random.randrange(0, 255), 255, random.randrange(0, 255))
            draw.point(xy, fill=fill)
        # 定义验证码的备选值
        str1 = 'ABCD123EFGHIJK456LMNOPQRS789TUVWXYZ0'
        # 随机选取4个值作为验证码
        rand_str = ''
        for i in range(0, 4):
            rand_str += str1[random.randrange(0, len(str1))]
        # 构造字体对象，ubuntu的字体路径为“/usr/share/fonts/truetype/freefont”
        font = ImageFont.truetype('FreeMono.ttf', 30)
        # 构造字体颜色
        fontcolor = (255, random.randrange(0, 255), random.randrange(0, 255))
        # 绘制4个字
        draw.text((5, 2), rand_str[0], font=font, fill=fontcolor)
        draw.text((25, 2), rand_str[1], font=font, fill=fontcolor)
        draw.text((50, 2), rand_str[2], font=font, fill=fontcolor)
        draw.text((75, 2), rand_str[3], font=font, fill=fontcolor)
        # 释放画笔
        del draw
        # 存入session，用于做进一步验证
        request.session['verifycode'] = rand_str
        # 内存文件操作
        buf = BytesIO()
        # 将图片保存在内存中，文件类型为png
        im.save(buf, 'png')
        # 将内存中的图片数据返回给客户端，MIME类型为图片png
        return HttpResponse(buf.getvalue(), 'image/png')


class VerifyShowView(View):
    def get(self, request):
        return render(request, 'verify_show.html')


class VerifyYzView(View):
    def post(self, request):
        yzm = request.POST.get('yzm')
        verifycode = request.session['verifycode']
        response = HttpResponse('no')
        if yzm.lower() == verifycode.lower():
            response = HttpResponse('ok')
        return response


class PassRecView(View):
    def get(self, request):
        params = request.GET['name']
        rec_object = Rec.objects.get(id=int(params))
        rec_object.verify = 2
        rec_object.lock = 0
        rec_object.who = request.user
        rec_object.verify_time = timezone.now()
        rec_object.save()
        return redirect('/rebate/admin/rebate/recmine/')


class UnPassRecView(View):
    def get(self, request):
        params = request.GET['name']
        rec_object = Rec.objects.get(id=int(params))
        rec_object.verify = 3
        rec_object.lock = 0
        rec_object.who = request.user
        rec_object.verify_time = timezone.now()
        rec_object.save()
        return redirect('/rebate/admin/rebate/recmine/')




