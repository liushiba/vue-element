from django.apps import AppConfig


class RebateConfig(AppConfig):
    name = 'rebate'
