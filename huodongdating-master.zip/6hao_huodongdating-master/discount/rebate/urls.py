# -*- coding: utf-8 -*-
# 18-7-31 下午1:58
# AUTHOR:June
from django.conf.urls import url
from rebate.views import IndexView, ItemView, RecView, MineView, QueryView, SkipView, PassView\
    , IndexWapView, RecWapView, IndexWapDetailView, MineWapView, VerifyCodeView, VerifyShowView\
    , VerifyYzView, PassRecView, UnPassRecView
app_name = 'rebate'

urlpatterns = [
    url(r'^index$', IndexView.as_view(), name='index'),
    url(r'indexwap$', IndexWapView.as_view(), name='indexwap'),
    url(r'indexwapdetail$', IndexWapDetailView.as_view(), name='indexwapdetail'),
    url(r'items$', ItemView.as_view(), name='items'),
    url(r'rec$', RecView.as_view(), name='rec'),
    url(r'recwap$', RecWapView.as_view(), name='recwap'),
    url(r'mine$', MineView.as_view(), name='mine'),
    url(r'minewap$', MineWapView.as_view(), name='minewap'),
    url(r'query$', QueryView.as_view(), name='query'),
    url(r'^skip/$', SkipView.as_view(), name='skip'),
    url(r'^pass/$', PassView.as_view(), name='pass'),
    url(r'verifycode$', VerifyCodeView.as_view(), name='verifycode'),
    url(r'verifyshow$', VerifyShowView.as_view(), name='verifyshow'),
    url(r'verifyyz$', VerifyYzView.as_view(), name='verifyyz'),
    url(r'^passrec/$', PassRecView.as_view(), name='passrec'),
    url(r'^unpassrec/$', UnPassRecView.as_view(), name='unpassrec'),
    url(r'^$', IndexView.as_view(), name='index'),
]

