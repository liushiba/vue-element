from django.apps import AppConfig


class MosaicConfig(AppConfig):
    name = 'apps.mosaic'
