from django.conf.urls import url, include
from rest_framework.routers import DefaultRouter
from rest_framework_jwt.views import verify_jwt_token, ObtainJSONWebToken, obtain_jwt_token
from active.views import AdminViewSet, ItemViewSet, RecordViewSet, ActiveView, FreshView, CodeView, ResViewSet, \
    IndexView, RecordView
from django.views.generic import TemplateView
from django.views.static import serve
from hd import settings

router = DefaultRouter()
router.register(r'admins', AdminViewSet, base_name='admins')
router.register(r'items', ItemViewSet, base_name='items')
router.register(r'records', RecordViewSet, base_name='records')
router.register(r'texts', ResViewSet, base_name='res')


urlpatterns = [
    url(r'login', ObtainJSONWebToken.as_view()),
    url(r'^info$', verify_jwt_token),
    # url(r'^api/admin$', TemplateView.as_view(template_name="index.html"), name="index"),
    url(r'^api/verifycode/$', CodeView.as_view(), name='verifycode'),
    url(r'^api/resource/(?P<res>\w+)$', RecordView.as_view(), name='showRec'),
    url(r'^api/active/$', ActiveView.as_view(), name='active'),
    url(r'^api/active/(?P<pid>\d+)$', ActiveView.as_view(), name='active'),
    url(r'^api/records/new/$', FreshView.as_view(), name='new'),
    url(r'^api/', include(router.urls)),
    # url(r'', TemplateView.as_view(template_name="index.html"), name="index"),
    url(r'^media/(?P<path>.*)', serve, {'document_root': settings.MEDIA_ROOT}),
    # url(r'', IndexView.as_view(), name="index"),

]
