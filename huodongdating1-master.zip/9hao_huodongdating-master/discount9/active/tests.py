import random

prelist=["130", "131", "132", "133", "134", "135", "136", "137", "138", "139",
                 "147", "150", "151", "152", "153", "155", "156", "157", "158", "159",
                 "186", "187", "188", "189"]


with open('myData.csv', 'a', encoding='UTF-8') as file_object:
    file_object.write('%s,%s,%s,%s,%s\n' % ('邮箱', '电话', 'QQ', '彩金', '名字'))
    for i in range(10):
        name = '张三'+str(i)
        email = '996%s@qq.com' %i
        tel = random.choice(prelist) + "".join(random.choice("0123456789") for i in range(8))
        qq = random.choice(prelist) + "".join(random.choice("0123456789") for i in range(8))
        money = i + 1
        file_object.write('%s,%s,%s,%s,%s\n' %(email,tel,qq,money,name ))
