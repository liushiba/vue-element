from django.apps import AppConfig


class ActiveConfig(AppConfig):
    name = 'active'
