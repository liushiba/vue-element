from django.urls import path
from apps.home.views import *

app_name = 'home'
urlpatterns = [
    path('', IndexView.as_view()),
    path('search', SearchView.as_view(), name='search'),
    path('wapIndex', WapIndexView.as_view(), name='wapIndex'),
    path('wapDayRank', WapDayRankView.as_view(), name='wapDayRank'),
    path('wapMonthRank', WapMonthRankView.as_view(), name='wapMonthRank')
]
