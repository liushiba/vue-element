# from django.core import serializers
# from django.core.serializers import serialize
import datetime
from django.db.migrations import serializer
from django.http import JsonResponse
from django.shortcuts import render
from django.views import View
from apps.news.models import *
from apps.agent.models import DayCommission, Month_Commission
from utils.getDateList import get_day_list, get_month_list


class IndexView(View):
    """前台首页"""

    def get(self, request):
        # 获取日佣金上传时间的列表
        dayobjs = DayCommission.objects.all().values_list('submit_time', flat=True).distinct().order_by('-submit_time')
        day_objs = map(lambda x: x[:10], dayobjs)  # 切割
        # 获取月佣金上传时间礼列表
        monthobjs = Month_Commission.objects.all().values_list('submit_time', flat=True).distinct().order_by(
            '-submit_time')
        month_list = list(map(lambda x: x[:7], monthobjs))  # 切割
        month_date = list(set(month_list))  # 去重
        month_date.sort(key=month_list.index)  # 排序
        # 获取公告
        new_obj = News.objects.first()
        # 获取单页
        about_obj = About.objects.first()
        return render(
            request,
            'index.html',
            {
                'day_date': day_objs,
                'month_date': month_date,
                'newobj': new_obj,
                'about_obj': about_obj
            })


class SearchView(View):
    """搜索"""

    def get(self, request):
        user_name = request.GET.get('user_name')
        obj = DayCommission.objects.filter(user_name=user_name).order_by('-submit_time').first()
        if obj:
            data = {
                "user_name": obj.user_name,
                # "member_number": obj.member_number,
                # "betting_amount": obj.betting_amount,
                # "bonus": obj.bonus,
                # "submit_time": obj.submit_time,
                "agent_url": obj.agent_url,
                "commission": obj.commission,
                # "compute_status": obj.compute_status,
                "status": '已派发' if obj.status else '未派发'
            }
            # 判断结算方式
            data['type'] = '日结'
            # 判断是否是当日
            if obj.submit_time[:11] == datetime.date.today():
                data['pre'] = '当日'
            else:
                data['pre'] = obj.submit_time[:11]
            return JsonResponse({'code': 200, 'data': data})
        else:
            return JsonResponse({'code': 400, 'msg': '没有查到该用户信息'})


class WapIndexView(View):
    """wap首页"""

    def get(self, request):
        # 获取公告
        new_obj = News.objects.first()
        return render(request, 'wapindex.html', {'newobj': new_obj})


class WapDayRankView(View):
    """手机端日排行"""

    def get(self, request):
        # 获取日佣金上传时间的列表
        day_date_list = get_day_list()
        # 获取公告
        new_obj = News.objects.first()
        return render(request, 'wapdayrank.html', {'day_date': day_date_list, 'newobj': new_obj})


class WapMonthRankView(View):
    """手机端月排行"""

    def get(self, request):
        # 获取月佣金上传时间的列表
        month_date_list = get_month_list()
        # 获取公告
        new_obj = News.objects.first()
        return render(request, 'wapmonthrank.html', {'month_date': month_date_list, 'newobj': new_obj})
