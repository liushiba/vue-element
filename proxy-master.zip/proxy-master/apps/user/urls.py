from django.urls import path
from apps.user.views import *
from django.conf.urls import url

app_name = 'user'
urlpatterns = [
    # 后台登录
    path('login', LoginView.as_view(), name='login'),
    path('logout', LogoutView.as_view(), name='logout'),
    path('captcha', CaptchaView.as_view(), name='captcha'),
    # 用户管理
    path('user', UserView.as_view(), name='user'),
    path('adduser', AddUserView.as_view(), name='adduser'),
    path('mdfPassword', MdfPasswordView.as_view(), name='mdfPassword'),
    path('mdfUserGroup', MdfUserGroupView.as_view(), name='mdfUserGroup'),
    path('delUser', DeleteUserView.as_view(), name='deleteUser'),
    # 规则管理
    path('rule', RuleView.as_view(), name='rule'),
    path('mdfRule', MdfRuleView.as_view(), name='mdfRule'),
    path('addRule', AddRuleView.as_view(), name='addRule'),
    path('delRule', DelRuleView.as_view(), name='delRule'),
    # 用户组管理
    path('group', GroupView.as_view(), name='group'),
    path('addGroup', AddGroupView.as_view(), name='addGroup'),
    path('mdfGroup', MdfGroupView.as_view(), name='mdfGroup'),
    path('delGroup', DelGroupView.as_view(), name='delGroup'),
    path('mdfGroupRule', MdfGroupRuleView.as_view(), name='mdfGroupRule'),
    # 后台首页
    path('', IndexView.as_view(), name='index'),
]
