import json
from django.contrib.auth import logout, authenticate, login
from django.views import View
from django.core.cache import cache
from utils.captcha import checkcode
from utils.fenye import fenye
from django.urls import reverse
from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
from apps.user.models import User, UserGroup, Rule


class IndexView(View):
    """后台首页"""

    def get(self, request):
        return render(request, 'adminIndex.html')


class LoginView(View):
    """登录"""

    def get(self, request):
        return render(request, 'adminLogin.html')

    def post(self, request):
        # 登录逻辑与获取用户菜单列表　和　权限列表到redis中，返回首页，经过中间件校验用户的权限确定能不能进入默认首页
        username = request.POST.get('username')
        password = request.POST.get('password')
        checkcode = request.POST.get('checkcode')
        # 参数校验
        if not all([username, password, checkcode]):
            return JsonResponse({'message': '请输入完整信息'})
        verifycode = request.session.get('captcha', '')
        if checkcode.lower() != verifycode.lower():
            return JsonResponse({'message': '验证码错误'})
        user = authenticate(username=username, password=password)
        if user:
            # 用户名和密码正确
            login(request, user)
            # 获取用户登录之前访问的url地址，没有则获取首页url
            next_url = request.GET.get('next', reverse('user:index'))  # None
            # 获取登录用户的所有权限
            rule_url_list = []
            if user.group_id:
                rule_id_list = user.group_id.rules.split(",")
                for i in rule_id_list:
                    try:
                        obj = Rule.objects.get(id=int(i))
                    except Exception as e:
                        continue
                    rule_url_list.append(obj.url)
            else:
                rule_url_list = []
            # request.session['rule_url_list'] = rule_url_list
            cache.set("%s_pmsurl_list" %user.username, rule_url_list)
            # 跳转到首页
            return JsonResponse({'code': 200, 'next_url': next_url})

        else:
            # 用户名或密码错误
            return JsonResponse({'message': '用户名或密码错误，请重新输入！'})


class CaptchaView(View):
    """生成验证码"""

    def get(self, request):
        rand_str, buf = checkcode()
        request.session['captcha'] = rand_str
        return HttpResponse(buf.getvalue(), 'image/png')


class LogoutView(View):
    """退出"""

    def get(self, request):
        logout(request)
        return redirect(reverse('user:login'))


class UserView(View):
    """用户管理页"""

    def get(self, request):
        userlist = User.objects.filter(is_active=True).order_by('-id')
        page = request.GET.get('p', 1)
        context = fenye(userlist, page)
        return render(request, 'user/index.html', context)


class AddUserView(View):
    """添加用户"""

    def get(self, request):
        usergroup = UserGroup.objects.all()
        return render(request, 'user/addUser.html', {'data': usergroup})

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        realy_name = request.POST.get('realy_name')
        group_id = request.POST.get('group_id')
        if username == '':
            return JsonResponse({'code': 400, 'msg': '用户名不能为空'})
        if password == '':
            return JsonResponse({'code': 400, 'msg': '密码不能为空'})
        try:
            obj = User.objects.get(username=username)
        except Exception as e:
            user_obj = User.objects.create_user(
                username=username,
                password=password,
                realy_name=realy_name if realy_name else '',
            )
            if group_id:
                user_obj.group_id = UserGroup.objects.get(id=int(group_id))
                user_obj.save()
            return JsonResponse({'code': 200, 'msg': '添加成功'})
        else:
            return JsonResponse({'code': 400, 'msg': '用户已存在'})


class MdfPasswordView(View):
    """修改密码"""

    def get(self, request):
        user_id = request.GET.get('id')
        try:
            user_obj = User.objects.get(id=user_id)
        except Exception as e:
            return redirect(reverse('user:user'))
        return render(request, 'user/mdfPassword.html', {'username': user_obj.username})

    def post(self, request):
        username = request.POST.get('username')
        new_password = request.POST.get('new_password')
        if not new_password:
            return JsonResponse({'code': 400, 'msg': '新密码不能为空'})
        try:
            user_obj = User.objects.get(username=username)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '用户不存在'})
        user_obj.set_password(new_password)
        user_obj.save()
        return JsonResponse({'code': 200, 'msg': '修改密码成功'})


class MdfUserGroupView(View):
    """修改用户组"""

    def get(self, request):
        user_id = request.GET.get('id')
        try:
            user_obj = User.objects.get(id=user_id)
        except Exception as e:
            return redirect(reverse('user:user'))
        group_list = UserGroup.objects.all()
        if user_obj.group_id:
            user_group = user_obj.group_id.name
        else:
            user_group = user_obj.group_id = None
        return render(request, 'user/mdfUserGroup.html',
                      {'group_list': group_list, 'user_group': user_group, 'username': user_obj.username})

    def post(self, request):
        user_name = request.POST.get('user_name')
        group_id = request.POST.get('group_id')
        try:
            user_obj = User.objects.get(username=user_name)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '用户不存在'})
        try:
            group_obj = UserGroup.objects.get(id=group_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '组不存在'})
        user_obj.group_id = group_obj
        user_obj.save()
        return JsonResponse({'code': 200, 'msg': '修改成功'})


class DeleteUserView(View):
    """删除用户"""

    def post(self, request):
        user_id = request.POST.get('user_id')
        try:
            user_obj = User.objects.get(id=user_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '用户不存在'})
        user_obj.is_active = False
        user_obj.save()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


class RuleView(View):
    """规则"""

    def get(self, request):
        ruleobj = Rule.objects.all()
        page = request.GET.get('p', 1)
        context = fenye(ruleobj, page)
        return render(request, 'rule/rule.html', context)


class AddRuleView(View):
    """添加规则"""

    def get(self, request):
        return render(request, 'rule/addRule.html')

    def post(self, request):
        rulename = request.POST.get('rulename')
        ruletitle = request.POST.get('ruletitle')
        channel = request.POST.get('channel')
        if not all([rulename, ruletitle, channel]):
            return JsonResponse({'code': 400, 'msg': '请输入完整的信息'})
        try:
            rule_obj = Rule.objects.get(url=rulename)
        except Exception as e:
            Rule.objects.create(
                url=rulename,
                title=ruletitle,
                channel=channel,
            )
            return JsonResponse({'code': 200, 'msg': '添加成功'})
        else:
            return JsonResponse({'code': 400, 'msg': '该规则url已存在'})


class MdfRuleView(View):
    """修改规则"""

    def get(self, request):
        rule_id = request.GET.get('id')
        try:
            rule_obj = Rule.objects.get(id=rule_id)
        except Exception as e:
            ruleobj = Rule.objects.all()
            page = request.GET.get('p', 1)
            context = fenye(ruleobj, page)
            return render(request, 'rule/rule.html', context)
        return render(request, 'rule/mdfRule.html', {"rule_obj": rule_obj})

    def post(self, request):
        rule_id = request.POST.get('ruleid')
        rulename = request.POST.get('rulename')
        ruletitle = request.POST.get('ruletitprintle')
        channel = request.POST.get('channel')
        if not all([rule_id, rulename, ruletitle, channel]):
            return JsonResponse({'code': 400, 'msg': '请输入完整的信息'})
        try:
            rule_obj = Rule.objects.get(id=rule_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '不存在的规则'})
        try:
            ruleobj = Rule.objects.get(url=rulename)
        except Exception as e:
            rule_obj.url = rulename
            rule_obj.title = ruletitle
            rule_obj.channel = channel
            rule_obj.save()
            return JsonResponse({'code': 200, 'msg': '修改成功'})
        else:
            if ruleobj.id == int(rule_id):
                ruleobj.title = ruletitle
                ruleobj.channel = channel
                ruleobj.save()
                return JsonResponse({'code': 200, 'msg': '修改成功'})
            return JsonResponse({'code': 400, 'msg': '该规则url已存在'})


class DelRuleView(View):
    """删除规则"""

    def post(self, request):
        rule_id = request.POST.get('ruleid')
        try:
            rule_obj = Rule.objects.get(id=rule_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '删除失败,规则不存在'})
        rule_obj.delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


class GroupView(View):
    """用户组管理"""

    def get(self, request):
        group_obj = UserGroup.objects.all()
        page = request.GET.get('p', 1)
        context = fenye(group_obj, page)
        return render(request, 'group/group.html', context)


class AddGroupView(View):
    """添加组"""

    def get(self, request):
        return render(request, 'group/addGroup.html')

    def post(self, request):
        group_name = request.POST.get('groupname')
        if not group_name:
            return JsonResponse({'code': 400, 'msg': '请输入组名称'})
        try:
            UserGroup.objects.get(name=group_name)
        except Exception as e:
            UserGroup.objects.create(name=group_name)
            return JsonResponse({'code': 200, 'msg': '添加成功'})
        return JsonResponse({'code': 400, 'msg': '组已存在'})


class MdfGroupRuleView(View):
    """修改组的规则"""

    def get(self, request):
        group_id = request.GET.get('id')
        try:
            group_obj = UserGroup.objects.get(id=group_id)
        except Exception as e:
            return render(request, 'group/group.html')
        rule_all = Rule.objects.all()
        # 获取规则分组
        group_list = []
        for i in rule_all:
            group_list.append(i.channel)
        # 规则分组去重
        group_list = sorted(set(group_list), key=group_list.index)
        # 组织数据格式为 [{'groupname': '用户管理', 'ruleobj': [<Rule: Rule object (3)>, <Rule: Rule object (4)>]} ]
        data_dict = []
        for i in group_list:
            data = {}
            data['groupname'] = i
            data['ruleobj_list'] = []
            rule_objs = rule_all.filter(channel=i)
            for r in rule_objs:
                data['ruleobj_list'].append(r)
            data_dict.append(data)
        # 如果该组有规则 把改组的规则[列表]传到前段作为 选中依据
        ruleid_list = []
        if group_obj.rules:
            ruleid_list = group_obj.rules.split(',')
            ruleid_list = list(map(int, ruleid_list))
        return render(request, 'group/mdfGroupRule.html',
                      {'data': data_dict, 'groupobj': group_obj, 'ruleid_list': ruleid_list})

    def post(self, request):
        group_id = request.POST.get('group_id')
        rule_list = json.loads(request.POST.get('rule_list'))
        rule_str = ','.join(rule_list)
        try:
            group_obj = UserGroup.objects.get(id=group_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '非法操作'})
        group_obj.rules = rule_str
        group_obj.save()
        return JsonResponse({'code': 200, 'msg': '修改成功'})


class MdfGroupView(View):
    """修改组"""

    def get(self, request):
        group_id = request.GET.get('id')
        try:
            group_obj = UserGroup.objects.get(id=group_id)
        except Exception as e:
            return render(request, 'group/group.html')
        return render(request, 'group/mdfGroup.html', {'group_obj': group_obj})

    def post(self, request):
        group_id = request.POST.get('groupid')
        group_name = request.POST.get('groupname')
        if not group_id:
            return JsonResponse({'code': 400, 'msg': '非法操作'})
        if not group_name:
            return JsonResponse({'code': 400, 'msg': '请输入组名'})
        try:
            group_obj = UserGroup.objects.get(id=group_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '非法操作'})
        try:
            group_obj = UserGroup.objects.get(name=group_name)
        except Exception as e:
            group_obj.name = group_name
            group_obj.save()
            return JsonResponse({'code': 200, 'msg': '修改成功'})
        return JsonResponse({'code': 400, 'msg': '该组已存在'})


class DelGroupView(View):
    """删除组"""

    def post(self, request):
        group_id = request.POST.get('groupid')
        try:
            group_obj = UserGroup.objects.get(id=group_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '组不存在'})
        group_obj.delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})
