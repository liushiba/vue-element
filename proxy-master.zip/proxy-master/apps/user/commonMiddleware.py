from django.utils.deprecation import MiddlewareMixin
from django.core.cache import cache
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.urls import reverse
import re


class PMS(MiddlewareMixin):
    def process_request(self, request):
        # 白名单
        whitelist = [
            r'^/$',  # 首页
            r'^/favicon.ico$',
            r'^/user/login$',
            r'^/user/captcha$',
            r'^/user/logout$',
            r'^/agent/dayRank$',  # 首页日排行接口
            r'^/agent/monthRank$',  # 首页月排行接口
            r'^/search$',  # 搜索页
            r'^/wapIndex$',  # 手机端首页
            r'^/wapDayRank$',  # 手机端查看日排行
            r'^/wapMonthRank$',  # 手机端查看日排行
            r'^/media/images/.*$'  # 上传的文件

        ]
        # 请求路径
        access_url = request.path
        # 如果访问路径是白名单网址
        is_whitelist = False
        for i in whitelist:
            if re.match(i, access_url):
                is_whitelist = True
                break
        if not is_whitelist:
            # 校验登录
            if not request.user.is_authenticated:
                return redirect(reverse('user:login'))
            if request.user.is_superuser:
                return None
            user_pms = cache.get('%s_pmsurl_list' % request.user.username)
            # 获取用户权限
            # user_pms = request.session.get('rule_url_list')
            # 获取权限为None或者没有权限
            if not user_pms or (access_url not in user_pms):
                if request.is_ajax():
                    return JsonResponse({'msg': "没有权限", 'code': 400})
                return render(request, 'error.html', {'errmsg': '没有权限'})
        else:
            return None
