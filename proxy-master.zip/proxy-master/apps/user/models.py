from django.db import models
from django.contrib.auth.models import AbstractUser


class Rule(models.Model):
    """规则"""
    url = models.CharField('规则url', max_length=100, unique=True)
    title = models.CharField('规则名称', max_length=100, blank=True, null=True)
    type = models.IntegerField('认证方式', choices=((1, '实时认证'), (2, '登录认证')), default=1)
    status = models.IntegerField('状态', choices=((0, '禁用'), (1, '正常')), default=1)
    condition = models.CharField('规则表达式，{id}>1表示用户的id字段大于1时验证才通过', default='{id}>1', max_length=50)
    channel = models.CharField('规则分组', max_length=50)
    visible = models.IntegerField('可见性', choices=((0, '不可见'), (1, '可见')), default=1)
    create_time = models.DateTimeField('创建时间', auto_now_add=True)


class UserGroup(models.Model):
    """用户组"""
    name = models.CharField('组名称', max_length=25, unique=True)
    rules = models.TextField('规则id')
    status = models.IntegerField('状态', choices=((0, '禁用'), (1, '正常')), default=1)
    create_time = models.DateTimeField('创建时间', auto_now_add=True)


class User(AbstractUser):
    """管理员表"""
    balance = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='余额', default=0)
    realy_name = models.CharField('真实姓名', max_length=15)
    group_id = models.ForeignKey(UserGroup, verbose_name='用户组', null=True, blank=True, on_delete=models.SET_NULL)

