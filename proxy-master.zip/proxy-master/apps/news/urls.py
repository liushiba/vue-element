from django.urls import path
from .views import *

app_name = 'news'

urlpatterns = [
    path('index', IndexView.as_view(), name='index'),
    path('addNews', AddNewsView.as_view(), name='addNews'),
    path('mdfNews', MdfNewsView.as_view(), name='mdfNews'),
    path('delNews', DelNewsView.as_view(), name='delNews'),
    path('batchDel', BatchDelView.as_view(), name='batchDel'),
    # path('search', SearchView.as_view(), name='search'),

    path('about', AboutView.as_view(), name='about'),
    path('addAbout', AddAboutView.as_view(), name='addAbout'),
    path('mdfAbout', MdfboutView.as_view(), name='mdfAbout'),
    path('delAbout', DelAboutView.as_view(), name='delAbout'),
    path('batchDelAbout', batchDelAboutView.as_view(), name='batchDelAbout')

]
