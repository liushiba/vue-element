from django.db import models
from DjangoUeditor.models import UEditorField


# Create your models here.


class Category(models.Model):
    """分类表"""
    name = models.CharField('分类名称', max_length=255, default='')
    sort = models.IntegerField('分类排序', default=0)
    pid = models.ForeignKey('self', verbose_name='父id', blank=True, null=True, on_delete=models.CASCADE)


class News(models.Model):
    """公告表"""
    title = models.CharField('标题', max_length=255, default='')
    link = models.CharField('链接', max_length=255, default='')
    content = models.TextField('内容')
    category_id = models.ForeignKey(Category, verbose_name='分类id', blank=True, null=True, on_delete=models.CASCADE)


class About(models.Model):
    """底部链接图片"""
    name = models.CharField('名称', null=True, blank=True, max_length=255)
    content = UEditorField(width=600,
                           height=300,
                           toolbars="full",
                           imagePath="images/",
                           filePath="files/",
                           upload_settings={"imageMaxSize": 1204000},
                           settings={},
                           verbose_name='内容')

