import json
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views import View
from utils.fenye import fenye
from .models import *
from django.forms import forms
from DjangoUeditor.forms import UEditorField


class IndexView(View):
    """公告列表"""

    def get(self, request):
        news_objs = News.objects.all()
        page = request.GET.get('p', 1)
        context = fenye(news_objs, page)
        categorys = Category.objects.all()
        context['categorys'] = categorys
        return render(request, 'news/index.html', context)


class AddNewsView(View):
    """添加公告"""

    def get(self, request):
        categorys = Category.objects.all()
        return render(request, 'news/add.html', {'categorys': categorys})

    def post(self, request):
        category_id = request.POST.get('category_id')
        title = request.POST.get('title')
        link = request.POST.get('link')
        if not title:
            return JsonResponse({'code': 400, 'msg': '内容不能为空'})
        try:
            category_obj = Category.objects.get(id=category_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '请选择类型'})
        News.objects.create(
            title=title,
            link=link,
            category_id=category_obj
        )
        return JsonResponse({'code': 200, 'msg': '添加成功'})


class DelNewsView(View):
    """删除公告"""

    def post(self, request):
        newsid = request.POST.get('newsid')
        try:
            newobj = News.objects.get(id=newsid)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '该公告不存在'})
        newobj.delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


class MdfNewsView(View):
    """修改公告"""

    def get(self, request):
        categorys = Category.objects.all()
        news_id = request.GET.get('id')
        try:
            news_obj = News.objects.get(id=news_id)
        except Exception as e:
            return redirect(reverse('news:index'))
        return render(request, 'news/save.html', {'categorys': categorys, 'news_obj': news_obj})

    def post(self, request):
        news_id = request.POST.get('newsid')
        category_id = request.POST.get('category_id')
        title = request.POST.get('title')
        link = request.POST.get('link')
        if not title:
            return JsonResponse({'code': 400, 'msg': '内容不能为空'})
        try:
            news_obj = News.objects.get(id=news_id)
        except Exception as e:
            return redirect(reverse('news:index'))
        try:
            category_obj = Category.objects.get(id=category_id)
        except Exception as e:
            return redirect(reverse('news:index'))
        news_obj.title = title
        news_obj.link = link
        news_obj.category_id = category_obj
        news_obj.save()
        return JsonResponse({'code': 200, 'msg': '修改成功'})


class BatchDelView(View):
    """批量删除"""

    def post(self, request):
        id_list = json.loads(request.POST.get('newid'))
        if not id_list:
            return JsonResponse({'code': 400, 'msg': '请选择内容'})
        for i in id_list:
            try:
                obj = News.objects.get(id=i)
            except Exception as e:
                pass
            else:
                obj.delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


class AboutView(View):
    """单页"""
    def get(self, request):
        page = request.GET.get('p', 1)
        objs = About.objects.all().order_by('-id')
        context = fenye(objs, page)
        return render(request, 'about/index.html', context)


class TestUEditorForm(forms.Form):
    """单页表单渲染与校验"""
    content = UEditorField('内容',
                           width=600,
                           height=300,
                           toolbars="full",
                           imagePath="images/",
                           filePath="files/",
                           upload_settings={"imageMaxSize": 1204000},
                           settings={}
                           )


class AddAboutView(View):
    """添加单页"""
    def get(self, request):
        form = TestUEditorForm()
        return render(request, 'about/add.html', {'form': form})

    def post(self, request):
        name = request.POST.get('name')
        form = TestUEditorForm(request.POST)
        if form.is_valid():
            content = form.cleaned_data['content']
            About.objects.create(name=name, content=content)
            # return render(request, 'about/add.html', {'form':form})
            return redirect(reverse('news:about'))
        return redirect(reverse('news:about'))


class MdfboutView(View):
    """修改单页"""

    def get(self, request):
        about_id = request.GET.get('id')
        try:
            obj = About.objects.get(id=about_id)
        except Exception as e:
            return redirect(reverse('news:about'))
        form = TestUEditorForm()
        return render(request, 'about/edit.html', {'about_obj':obj, 'form':form})

    def post(self, request):
        name = request.POST.get('name')
        about_id = request.POST.get('pid')
        try:
            about_obj = About.objects.get(id=about_id)
        except Exception as e:
            return redirect(reverse('news:about'))
        form = TestUEditorForm(request.POST)
        if form.is_valid():
            content = form.cleaned_data['content']
            about_obj.name=name
            about_obj.content=content
            about_obj.save()
            # return render(request, 'about/add.html', {'form':form})
            return redirect(reverse('news:about'))
        return redirect(reverse('news:about'))


class DelAboutView(View):
    """删除单页"""

    def post(self, request):
        aboutid = request.POST.get('aboutid')
        try:
            aboutobj = About.objects.get(id=aboutid)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '该单页不存在'})
        aboutobj.delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


class batchDelAboutView(View):
    """批量删除单页"""

    def post(self, request):
        id_list = json.loads(request.POST.get('aboutid'))
        if not id_list:
            return JsonResponse({'code': 400, 'msg': '请选择内容'})
        for i in id_list:
            try:
                obj = About.objects.get(id=i)
            except Exception as e:
                pass
            else:
                obj.delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


"""
class SearchView(View):


    def get(self, request):
        category_id = request.GET.get('category_id')
        page = request.GET.get('p', 1)
        try:
            category_obj = Category.objects.get(id=category_id)
        except Exception as e:
            return render(request, 'news/index.html')
        news_objs = News.objects.filter(category_id=category_obj)
        context = fenye(news_objs, page)
        categorys = Category.objects.all()
        context['categorys'] = categorys
        return render(request, 'news/search.html', context)
"""
