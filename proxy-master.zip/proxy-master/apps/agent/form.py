from django import forms


class CommissionForm(forms.Form):
    """日佣金方案"""

    betting_amount = forms.IntegerField(min_value=0, max_value=2147483647, error_messages={
        'required': '每日投注额不能为空',
        'min_value': '超出最小值0',
        'max_value': '超出最大值2147483647',
        'invalid': '必须为整数类型',
    })

    member_number = forms.IntegerField(min_value=0, max_value=2147483647, error_messages={
        'required': '日活跃会员不能为空',
        'min_value': '超出最小值0',
        'max_value': '超出最大值2147483647',
        'invalid': '必须为整数类型',

    })

    percent = forms.DecimalField(min_value=0, max_value=100, error_messages={
        'required': '日佣金比例不能为空',
        'min_value': '日佣金比例超出范围0~100',
        'max_value': '日佣金比例超出范围0~100',
        'invalid': '必须为浮点数',
    })


class RankingListConfigForm(forms.Form):
    """排行榜设置"""
    day_rank_number = forms.IntegerField(min_value=0, max_value=99999, error_messages={
        'required': '日排行个数不能为空',
        'min_value': '日排行个数不能小于0',
        'max_value': '日排行个数超出5位数',
        'invalid': '必须为整数类型',
    })
    month_rank_number = forms.IntegerField(min_value=0, max_value=99999, error_messages={
        'invalid': '必须为整数类型',
        'required': '月排行个数不能为空',
        'min_value': '月排行个数不能小于0',
        'max_value': '月排行个数超出5位数'
    })


class DayCommissionForm(forms.Form):
    """日佣金记录"""
    user_name = forms.CharField(
        max_length=225,
        error_messages={
            'required': '代理账号不能为空',
            'max_length': '代理账号长度不能大于255个字符'
        })
    member_number = forms.IntegerField(
        required=True,
        min_value=0,
        max_value=2147483647,
        error_messages={
            'min_value': '会员数量不能小于0',
            'max_value': '会员数量不能大于2147483647',
            'invalid': '会员数必须为整数类型',
            'required': '会员数量不能为空'
        })
    betting_amount = forms.IntegerField(
        required=True,
        min_value=0,
        max_value=9223372036854775807,
        error_messages={
            'min_value': '投注额不能小于0',
            'max_value': '会员数量不能大于9223372036854775807',
            'invalid': '必须为整数类型',
            'required': '投注金额不能为空'
        }
    )
    bonus = forms.IntegerField(
        required=True,
        min_value=0,
        max_value=2147483647,
        error_messages={
            'min_value': '奖金不能小于0',
            'max_value': '奖金不能大于2147483647',
            'invalid': '奖金必须为整数类型',
            'required': '奖金不能为空'
        }
    )
    submit_time = forms.CharField(
        required=True,
        max_length=225,
        error_messages={
            'max_length': '长度不能大于225',
            'required': '时间不能为空'
        }
    )
    agent_url = forms.CharField(
        required=True,
        max_length=255,
        error_messages={
            'max_length': 'url长度不能大于225',
            'required': 'url不能为空'
        }
    )
    commission = forms.IntegerField(
        required=True,
        min_value=0,
        max_value=2147483647,
        error_messages={
            'min_value': '日佣金不能小于0',
            'max_value': '日佣金不能大于2147483647',
            'invalid': '必须为整数类型',
            'required': '日佣金不能为空'
        }
    )
    compute_status = forms.IntegerField(
        required=True,
        min_value=0,
        max_value=1,
        error_messages={
            'invalid': '计算状态1或0',
            'required': '计算状态不能为空',
            'min_value': '计算状态1或0',
            'max_value': '计算状态1或0',
        }
    )
    status = forms.IntegerField(
        required=True,
        min_value=0,
        max_value=1,
        error_messages={
            'invalid,': '派发状态只能1或0',
            'required': '派发状态只能1或0',
            'min_value': '派发状态1或0',
            'max_value': '派发状态1或0',
        }
    )


class MonthCommissionForm(forms.Form):
    user_name = forms.CharField(
        max_length=225,
        error_messages={
            'required': '代理账号不能为空',
            'max_length': '代理账号长度不能大于255个字符'
        })
    commission = forms.IntegerField(
        required=True,
        min_value=0,
        max_value=2147483647,
        error_messages={
            'min_value': '月佣金不能小于0',
            'max_value': '月佣金不能大于2147483647',
            'invalid': '必须为整数类型',
            'required': '月佣金不能为空'
        }
    )
    submit_time = forms.CharField(
        required=True,
        max_length=225,
        error_messages={
            'max_length': '时间长度不能大于225',
            'required': '时间不能为空'
        }
    )
    agent_url = forms.CharField(
        required=True,
        max_length=255,
        error_messages={
            'max_length': 'url长度不能大于225',
            'required': 'url不能为空'
        }
    )
    status = forms.IntegerField(
        required=True,
        min_value=0,
        max_value=1,
        error_messages={
            'invalid,': '派发状态只能1或0',
            'required': '派发状态只能1或0',
            'min_value': '派发状态1或0',
            'max_value': '派发状态1或0',
        }
    )
