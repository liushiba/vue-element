import json
import xlwt
from io import BytesIO
from django.utils.http import urlquote
from django.http import HttpResponse
from utils.djangoFormError import get_err_str
from .form import CommissionForm, RankingListConfigForm, DayCommissionForm, MonthCommissionForm
from django.urls import reverse
from utils.fenye import fenye
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.views import View
from utils.uploadFile import upload_file
from utils.importExcel import import_day_excel, import_month_excel
from utils.getDateList import get_day_list, get_month_list
from .models import *


class SalaryView(View):
    """日工资结算方案展示"""

    def get(self, request):
        salary_obj = Salary.objects.all()
        return render(request, 'agent/salaryIndex.html', {'salary_obj': salary_obj})


class AddSalaryView(View):
    """添加日工资结算方案"""

    def get(self, request):
        return render(request, 'agent/salaryAdd.html')

    def post(self, request):
        betting_amount = request.POST.get('betting_amount')
        salary = request.POST.get('salary')
        if not betting_amount:
            return JsonResponse({'code': 200, 'msg': '请输入投注额'})
        if not salary:
            return JsonResponse({'code': 200, 'msg': '请输入日工资'})
        Salary.objects.create(betting_amount=betting_amount, salary=salary)
        return redirect(reverse('agent:salary'))


class MdfSalaryView(View):
    """修改日工资结算方案"""

    def get(self, request):
        salary_id = request.GET.get('id')
        try:
            salary_obj = Salary.objects.get(id=salary_id)
        except Exception as e:
            return redirect(reverse('agent:salary'))
        return render(request, 'agent/salaryEdit.html', {'salary_obj': salary_obj})

    def post(self, request):
        salary_id = request.POST.get('id')
        betting_amount = request.POST.get('betting_amount')
        salary = request.POST.get('salary')
        if not betting_amount:
            return JsonResponse({'code': 200, 'msg': '请输入投注额'})
        if not salary:
            return JsonResponse({'code': 200, 'msg': '请输入日工资'})
        try:
            salary_obj = Salary.objects.get(id=salary_id)
        except Exception as e:
            return redirect(reverse('agent:salary'))
        salary_obj.betting_amount = betting_amount
        salary_obj.salary = salary
        salary_obj.save()
        return redirect(reverse('agent:salary'))


class DelSalaryView(View):
    """删除日工资结算方案"""

    def post(self, request):
        salary_id = request.POST.get('salary_id')
        try:
            salary_obj = Salary.objects.get(id=salary_id)
        except Exception as e:
            return redirect(reverse('agent:salary'))
        salary_obj.delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


class CommissionView(View):
    """日佣金结算方案"""

    def get(self, request):
        objs = Commission.objects.all()
        return render(request, 'agent/commissionIndex.html', {'objs': objs})


class AddCommissionView(View):
    """添加日佣金结算方案"""

    def get(self, request):
        return render(request, 'agent/commissionAdd.html')

    def post(self, request):
        commission = CommissionForm(request.POST)
        if commission.is_valid():
            obj = Commission.objects.create(betting_amount=commission.cleaned_data['betting_amount'],
                                            member_number=commission.cleaned_data['member_number'],
                                            percent=commission.cleaned_data['percent']
                                            )
            return JsonResponse({'code': 200, 'msg': '添加成功'})
        else:
            errmsg = get_err_str(commission)
            return JsonResponse({'code': 400, 'msg': errmsg})


class MdfCommissionView(View):
    """修改佣金方案"""

    def get(self, request):
        commission_id = request.GET.get('id')
        try:
            obj = Commission.objects.get(id=commission_id)
        except Exception as e:
            return redirect(reverse('agent:commission'))
        return render(request, 'agent/commissionEdit.html', {'obj': obj})

    def post(self, request):
        commission_id = request.POST.get('commission_id')
        try:
            obj = Commission.objects.get(id=commission_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '请刷新页面'})
        commission = CommissionForm(request.POST)
        if commission.is_valid():
            obj.betting_amount = commission.cleaned_data['betting_amount']
            obj.member_number = commission.cleaned_data['member_number']
            obj.percent = commission.cleaned_data['percent']
            obj.save()
            return JsonResponse({'code': 200, 'msg': '修改成功'})
        else:
            errmsg = get_err_str(commission)
            return JsonResponse({'code': 400, 'msg': errmsg})


class DelCommissionView(View):
    """删除佣金方案"""

    def post(self, request):
        commission_id = request.POST.get('commission_id')
        try:
            obj = Commission.objects.get(id=commission_id)
        except Exception as e:
            return JsonResponse({'code': 200, 'msg': '获取不到id'})
        obj.delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


class RankConfigView(View):
    """配置日月排行个数"""

    def get(self, request):
        rankobj = RankingListConfig.objects.filter().first()
        return render(request, 'agent/rankConfig.html', {'rankobj': rankobj})

    def post(self, request):
        rankconfig_id = request.POST.get('rank_id')
        obj = RankingListConfig.objects.first()
        if not obj:
            obj = RankingListConfig.objects.create(id=1, day_rank_number=0, month_rank_number=0)
        try:
            obj = RankingListConfig.objects.get(id=rankconfig_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '非法操作'})
        form = RankingListConfigForm(request.POST)
        if form.is_valid():
            obj.day_rank_number = form.cleaned_data['day_rank_number']
            obj.month_rank_number = form.cleaned_data['month_rank_number']
            obj.save()
            return JsonResponse({'code': 200, 'msg': '修改成功'})
        else:
            errmsg = get_err_str(form)
            return JsonResponse({'code': 400, 'msg': errmsg})


class DayRankView(View):
    """查看日排行榜数据"""

    def get(self, request):
        day_date_list = get_day_list()
        return render(request, 'agent/rank.html', {'datelist': day_date_list})

    def post(self, request):
        date = request.POST.get('period')
        # 获取排行榜配置数据（显示个数）
        obj = RankingListConfig.objects.last()
        if obj:
            num = obj.day_rank_number
        else:
            num = 10
        date += ' 00:00:00'
        objs = DayCommission.objects.filter(submit_time=date).order_by('-betting_amount')[:num]
        html_str = ''
        Ranking = 1
        for i in objs:
            html_str += '<tr><td>' + i.user_name + '</td><td>' + str(i.betting_amount) + '</td><td>' + str(
                Ranking) + '</td></tr>'
            Ranking += 1
        return JsonResponse({'code': 200, 'data': html_str})


class MonthRankView(View):
    """查看月排行数据"""

    def get(self, request):
        month_date_list = get_month_list()
        return render(request, 'agent/monthRank.html', {'datelist': month_date_list})

    def post(self, request):
        rank_obj = RankingListConfig.objects.first()  # 排行个数
        rank_num = 10
        if rank_obj:
            rank_num = rank_obj.month_rank_number
        month = request.POST.get('period')
        objs = Month_Commission.objects.filter(submit_time__contains=month).order_by('-commission')[:rank_num]
        html_str = ''
        ranking = 1
        for i in objs:
            html_str += '<tr><td>' + i.user_name + '</td><td>' + str(i.commission) + '</td><td>' + str(
                ranking) + '</td></tr>'
            ranking += 1
        return JsonResponse({'code': 200, 'data': html_str})


class DayRankDownloadView(View):
    """日排行数据下载"""

    def get(self, request):
        date_str = request.GET.get('d')
        # date_str += ' 00:00:00'
        rank_obj = RankingListConfig.objects.first()
        data = DayCommission.objects.filter(submit_time__contains=date_str)
        # 设置头信息
        response = HttpResponse(content_type='application/ms-excel')
        response['Content-Disposition'] = 'attachment;filename=' + urlquote(u'日排行') + date_str[:10] + '.xls'
        if data.exists():
            if not rank_obj:
                rank_num = 10
            else:
                rank_num = rank_obj.day_rank_number
            data = data.order_by('-betting_amount')[:rank_num]
            # 创建工作簿
            ws = xlwt.Workbook(encoding='utf-8')
            # 创建一张表
            w = ws.add_sheet('sheet1')
            # 表头
            line_head = ["代理账号", "日佣金", "排名"]
            for i, v in enumerate(line_head):
                w.write(0, i, v)
            # 写入数据
            excel_row = 1  # 第二行开始
            rank = 1
            for obj in data:
                # 写入每一行对应的数据
                w.write(excel_row, 0, obj.user_name)
                w.write(excel_row, 1, obj.betting_amount)
                w.write(excel_row, 2, rank)
                excel_row += 1
                rank += 1
            # 写出到IO
            output = BytesIO()
            ws.save(output)
            # 重新定位到开始
            output.seek(0)
            response.write(output.getvalue())
        return response


class MonthRankDownloadView(View):
    """月排行数据下载"""

    def get(self, request):
        date_str = request.GET.get('m')  # 获取月份
        rank_obj = RankingListConfig.objects.first()  # 排行个数
        rank_num = 10
        if rank_obj:
            rank_num = rank_obj.month_rank_number
        data = Month_Commission.objects.filter(submit_time__contains=date_str).order_by('-commission')[:rank_num]
        # 设置头信息
        response = HttpResponse(content_type='application/ms-excel')
        response['Content-Disposition'] = 'attachment;filename=' + 'monthrank' + date_str + '.xls'
        if data.exists():
            # 创建工作簿
            ws = xlwt.Workbook(encoding='utf-8')
            # 创建一张表
            w = ws.add_sheet('sheet1')
            # 表头
            line_head = ["代理账号", "月佣金", "排名"]
            for i, v in enumerate(line_head):
                w.write(0, i, v)
            # 写入数据
            excel_row = 1  # 第二行开始
            rank = 1
            for obj in data:
                # 写入每一行对应的数据
                w.write(excel_row, 0, obj.user_name)
                w.write(excel_row, 1, obj.commission)
                w.write(excel_row, 2, rank)
                excel_row += 1
                rank += 1
            # 写出到IO
            output = BytesIO()
            ws.save(output)
            # 重新定位到开始
            output.seek(0)
            response.write(output.getvalue())

        return response


class DayCommissionView(View):
    """日佣金管理"""

    def get(self, request):
        page = request.GET.get('p', 1)
        status = request.GET.get('status', '')
        search_word = request.GET.get('user_name', '')
        objs = DayCommission.objects.all().order_by('-id')
        if status:
            objs = objs.filter(status=status)
        if search_word:
            objs = objs.filter(user_name=search_word)
        context = fenye(objs, page, 50)
        context['status'] = status
        context['search_word'] = search_word
        return render(request, 'agent/index.html', context)


class BatchDeleteView(View):
    """批量删除"""

    def post(self, request):
        id_list = json.loads(request.POST.get('id_list'))
        num = DayCommission.objects.filter(id__in=id_list).delete()
        return JsonResponse({'code': 200, 'msg': '成功删除%s条数据' % num[0]})


class DeleteAllView(View):
    """删除所有"""

    def post(self, request):
        num = DayCommission.objects.all().delete()
        return JsonResponse({'code': 200, 'msg': '清除成功，共删除%s条数据' % num[0]})


class DelDayCommissionView(View):
    def post(self, request):
        obj_id = request.POST.get('obj_id')
        try:
            obj = DayCommission.objects.get(id=obj_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '非法操作'})
        obj.delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


class MdfDayCommissionView(View):
    """修改日佣金"""

    def get(self, request):
        obj_id = request.GET.get('id')
        try:
            obj = DayCommission.objects.get(id=obj_id)
        except Exception as e:
            return redirect(reverse('agent:dayCommission'))
        return render(request, 'agent/edit.html', {'obj': obj})

    def post(self, request):
        obj_id = request.POST.get('id')
        try:
            obj = DayCommission.objects.get(id=obj_id)
        except Exception as e:
            return redirect(reverse('agent:dayCommission'))
        form = DayCommissionForm(request.POST)
        if form.is_valid():
            obj.user_name = form.cleaned_data['user_name']
            obj.member_number = form.cleaned_data['member_number']
            obj.betting_amount = form.cleaned_data['betting_amount']
            obj.bonus = form.cleaned_data['bonus']
            obj.submit_time = form.cleaned_data['submit_time']
            obj.agent_url = form.cleaned_data['agent_url']
            obj.commission = form.cleaned_data['commission']
            obj.compute_status = form.cleaned_data['compute_status']
            obj.status = form.cleaned_data['status']
            obj.save()
            return JsonResponse({'code': 200, 'msg': '修改成功'})
        else:
            errmsg = get_err_str(form)
            return JsonResponse({'code': 400, 'msg': errmsg})


class AddDayCommissionView(View):
    """添加日佣金"""

    def get(self, request):
        return render(request, 'agent/add.html')

    def post(self, request):
        form = DayCommissionForm(request.POST)
        if form.is_valid():
            DayCommission.objects.create(
                user_name=form.cleaned_data['user_name'],
                member_number=form.cleaned_data['member_number'],
                betting_amount=form.cleaned_data['betting_amount'],
                bonus=form.cleaned_data['bonus'],
                submit_time=form.cleaned_data['submit_time'],
                agent_url=form.cleaned_data['agent_url'],
                commission=form.cleaned_data['commission'],
                compute_status=form.cleaned_data['compute_status'],
                status=form.cleaned_data['status'],
            )
            return JsonResponse({'code': 200, 'msg': '添加成功'})
        else:
            errmsg = get_err_str(form)
            return JsonResponse({'code': 400, 'msg': errmsg})


class ImportExcelView(View):
    """导入excel"""

    def post(self, request):
        excel_obj = request.FILES.get('excel', '')
        # 将上传文件写入本地
        upload_info = upload_file(excel_obj, ['xlsx', 'xls'], 'upload_day_excel')
        if not upload_info['result']:
            return JsonResponse({'code': 400, 'msg': upload_info['msg']})
        data = import_day_excel(upload_info['path'])
        if not data['result']:
            return JsonResponse({'code': 400, 'msg': data['msg']})
        return JsonResponse({'code': 200, 'msg': data['msg']})


class SendView(View):
    """派送"""

    def post(self, request):
        obj_id = request.POST.get('obj_id')
        try:
            obj = DayCommission.objects.get(id=obj_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '非法操作'})
        if obj.compute_status:
            obj.status = True
            obj.save()
            return JsonResponse({'code': 200, 'msg': '派送成功'})
        else:
            return JsonResponse({'code': 400, 'msg': '派送失败，先计算'})


class BatchSendView(View):
    """批量派送"""

    def post(self, request):
        id_list = json.loads(request.POST.get('id_list'))
        num = DayCommission.objects.filter(id__in=id_list, compute_status=True, status=False).update(status=True)
        if num:
            return JsonResponse({'code': 200, 'msg': '成功派送%s条数据' % num})
        else:
            return JsonResponse({'code': 400, 'msg': '失败，没有可派发数据(先计算)'})


class CalculationView(View):
    """计算"""

    def post(self, request):
        id_list = json.loads(request.POST.get('id_list'))
        for i in id_list:
            try:
                dayobj = DayCommission.objects.get(id=i)
            except Exception as e:
                continue
            # 判断计算状态
            if dayobj.compute_status:
                continue
            betting_amount = dayobj.betting_amount  # 日有效投注额
            member_number = dayobj.member_number  # 日活跃会员数
            # 计算日工资
            salary = 0
            for i in Salary.objects.all().order_by('-betting_amount'):
                if betting_amount >= i.betting_amount:
                    salary = i.salary
                    break
            # 计算佣金(先比较佣金，再比较会员数量)
            percent = 0  # 返佣百分比
            for obj in Commission.objects.all():
                if betting_amount >= obj.betting_amount:
                    for i in Commission.objects.all():
                        if member_number >= i.member_number:
                            percent = i.percent
            commission = (betting_amount * percent) / 100 + salary
            dayobj.compute_status = True
            dayobj.commission = commission
            dayobj.save()
        return JsonResponse({'code': 200, 'msg': '计算完成'})


class DownloadDataBeforeView(View):
    """下载前的查询"""

    def get(self, request):
        date_str = request.GET.get('date_str')
        date_str += ' 00:00:00'
        data = DayCommission.objects.filter(submit_time=date_str)
        if data.exists():
            return JsonResponse({'code': 200, 'msg': 'ok'})
        else:
            return JsonResponse({'code': 400, 'msg': 'nook'})


class DownloadDataView(View):
    """下载数据"""

    def get(self, request):
        date_str = request.GET.get('date_str')
        date_str += ' 00:00:00'
        data = DayCommission.objects.filter(submit_time=date_str)
        # 设置头信息
        response = HttpResponse(content_type='application/ms-excel')
        response['Content-Disposition'] = 'attachment;filename=' + 'day' + date_str[:10] + '.xls'
        if data.exists():
            # 创建工作簿
            ws = xlwt.Workbook(encoding='utf-8')
            # 创建一张表
            w = ws.add_sheet('sheet1')
            # 表头
            line_head = ["代理账号", "会员人数", "有效投注", "奖金", "提交时间", "专属链接", "日佣金", "计算状态", "派发状态"]
            for i, v in enumerate(line_head):
                w.write(0, i, v)
            # 写入数据
            excel_row = 1  # 第二行开始
            for obj in data:
                # 写入每一行对应的数据
                w.write(excel_row, 0, obj.user_name)
                w.write(excel_row, 1, obj.member_number)
                w.write(excel_row, 2, obj.betting_amount)
                w.write(excel_row, 3, obj.bonus)
                w.write(excel_row, 4, obj.submit_time)
                w.write(excel_row, 5, obj.agent_url)
                w.write(excel_row, 6, obj.commission)
                w.write(excel_row, 7, '已计算' if obj.compute_status else '未计算')
                w.write(excel_row, 8, '已派送' if obj.status else '未派送')
                excel_row += 1
            # 写出到IO
            output = BytesIO()
            ws.save(output)
            # 重新定位到开始
            output.seek(0)
            response.write(output.getvalue())
        return response


class MonthCommissionView(View):
    """月佣金"""

    def get(self, request):
        page = request.GET.get('p', 1)
        status = request.GET.get('status', '')
        search_word = request.GET.get('user_name', '')
        objs = Month_Commission.objects.all().order_by('-id')
        if status:
            objs = objs.filter(status=status)
        if search_word:
            objs = objs.filter(user_name=search_word)
        context = fenye(objs, page, 10)
        context['status'] = status
        context['search_word'] = search_word
        return render(request, 'agent/monthIndex.html', context)


class DelMonthCommissionView(View):
    """删除月佣金记录"""

    def post(self, request):
        obj_id = request.POST.get('obj_id')
        try:
            obj = Month_Commission.objects.get(id=obj_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '非法操作'})
        obj.delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


class MdfMonthCommissionView(View):
    """修改月佣金记录"""

    def get(self, request):
        id = request.GET.get('id')
        try:
            obj = Month_Commission.objects.get(id=id)
        except Exception as e:
            return redirect(reverse('agent:monthCommission'))
        return render(request, 'agent/monthEdit.html', {'obj': obj})

    def post(self, request):
        id = request.POST.get('id')
        try:
            obj = Month_Commission.objects.get(id=id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '非法操作'})

        form = MonthCommissionForm(request.POST)
        if form.is_valid():
            obj.user_name = form.cleaned_data['user_name']
            obj.commission = form.cleaned_data['commission']
            obj.submit_time = form.cleaned_data['submit_time']
            obj.agent_url = form.cleaned_data['agent_url']
            obj.status = form.cleaned_data['status']
            obj.save()
            return JsonResponse({'code': 200, 'msg': '修改成功'})
        else:
            errmsg = get_err_str(form)
            return JsonResponse({'code': 400, 'msg': errmsg})


class AddMonthCommission(View):
    """添加月佣金记录"""

    def get(self, request):
        return render(request, 'agent/monthAdd.html')

    def post(self, request):
        form = MonthCommissionForm(request.POST)
        if form.is_valid():
            Month_Commission.objects.create(
                user_name=form.cleaned_data['user_name'],
                commission=form.cleaned_data['commission'],
                submit_time=form.cleaned_data['submit_time'],
                agent_url=form.cleaned_data['agent_url'],
                status=form.cleaned_data['status']
            )
            return JsonResponse({'code': 200, 'msg': '添加成功'})
        else:
            errmsg = get_err_str(form)
            return JsonResponse({'code': 400, 'msg': errmsg})


class ImportMonthExcelView(View):
    """导入excle"""

    def post(self, request):
        excel_obj = request.FILES.get('excel', '')
        # 将上传文件写入本地
        upload_info = upload_file(excel_obj, ['xlsx', 'xls'], 'upload_month_excel')
        if not upload_info['result']:
            return JsonResponse({'code': 400, 'msg': upload_info['msg']})
        data = import_month_excel(upload_info['path'])
        if not data['result']:
            return JsonResponse({'code': 400, 'msg': data['msg']})
        return JsonResponse({'code': 200, 'msg': data['msg']})


class SendMonthView(View):
    """月佣金派送"""

    def post(self, request):
        obj_id = request.POST.get('obj_id')
        try:
            obj = Month_Commission.objects.get(id=obj_id)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '非法操作'})
        obj.status = True
        obj.save()
        return JsonResponse({'code': 200, 'msg': '派送成功'})


class BatchSendMonthView(View):
    """批量派发月佣金"""

    def post(self, request):
        id_list = json.loads(request.POST.get('id_list'))
        num = Month_Commission.objects.filter(id__in=id_list, status=False).update(status=True)
        if num:
            return JsonResponse({'code': 200, 'msg': '成功派送%s条数据' % num})
        else:
            return JsonResponse({'code': 400, 'msg': '失败，没有可派发数据(先计算)'})


class BatchDeleteMonthView(View):
    """批量删除"""

    def post(self, request):
        id_list = json.loads(request.POST.get('id_list'))
        num = Month_Commission.objects.filter(id__in=id_list).delete()
        return JsonResponse({'code': 200, 'msg': '成功删除%s条数据' % num[0]})


class DeleteAllMonthView(View):
    """清空"""

    def post(self, request):
        Month_Commission.objects.all().delete()
        return JsonResponse({'code': 200, 'msg': '清空成功'})


class DownloadDataMonthBeforeView(View):
    """下载前的查询"""

    def get(self, request):
        date_str = request.GET.get('date_str')
        status = False
        for i in Month_Commission.objects.all():
            if i.submit_time[:7] == date_str:
                status = True
                break
        if status:
            return JsonResponse({'code': 200, 'msg': 'ok'})
        else:
            return JsonResponse({'code': 400, 'msg': 'nook'})


class DownloadDataMonthView(View):
    """下载月佣金excel"""

    def get(self, request):
        date_str = request.GET.get('date_str')
        data = []
        for i in Month_Commission.objects.all():
            if i.submit_time[:7] == date_str:
                data.append(i)
        # 设置头信息
        response = HttpResponse(content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment;filename=' + 'month' + date_str[:10] + '.xls'
        if data:
            ws = xlwt.Workbook(encoding='utf-8')  # 创建工作簿
            w = ws.add_sheet('sheet1')  # 创建一张表

            line_head = ["代理账号", "月佣金", "提交时间", "专属链接", "派发状态"]  # 表头
            # 写入数据
            for i, v in enumerate(line_head):
                w.write(0, i, v)
            excel_row = 1  # 第二行开始
            for obj in data:
                # 写入每一行对应的数据
                w.write(excel_row, 0, obj.user_name)
                w.write(excel_row, 1, obj.commission)
                w.write(excel_row, 2, obj.submit_time)
                w.write(excel_row, 3, obj.agent_url)
                w.write(excel_row, 4, '已派送' if obj.status else '未派送')
                excel_row += 1
            # 写出到IO
            output = BytesIO()
            ws.save(output)
            # 重新定位到开始
            output.seek(0)
            response.write(output.getvalue())
        return response


class ApplicationDataView(View):
    """修改结算申请"""

    def get(self, request):
        status = request.GET.get('status', '')
        user_name = request.GET.get('user_name', '')
        objs = Apply.objects.all()
        if status:
            objs = objs.filter(status=status)
        if user_name:
            objs = objs.filter(user_name=user_name)
        page = request.GET.get('p', 1)
        context = fenye(objs, page, 2)
        context['status'] = status
        context['user_name'] = user_name
        return render(request, 'agent/applyIndex.html', context)


class ApplicationDelView(View):
    """删除"""

    def post(self, request):
        id_list = json.loads(request.POST.get('idList'))
        is_delete_all = request.POST.get('is_delete_all')
        if is_delete_all == '1':
            Apply.objects.all().delete()
        else:
            Apply.objects.filter(id__in=id_list).delete()
        return JsonResponse({'code': 200, 'msg': '删除成功'})


class PassdView(View):
    """通过"""

    def post(self, request):
        pid = request.POST.get('pid')
        try:
            obj = Apply.objects.get(id=pid)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '非法操作'})
        obj.status = 1
        obj.save()
        return JsonResponse({'code': 200, 'msg': 'ok'})


class RefusedView(View):
    """拒绝"""

    def post(self, request):
        pid = request.POST.get('pid')
        try:
            obj = Apply.objects.get(id=pid)
        except Exception as e:
            return JsonResponse({'code': 400, 'msg': '非法操作'})
        obj.status = 2
        obj.save()
        return JsonResponse({'code': 200, 'msg': 'ok'})
