from django.urls import path
from apps.agent.views import *

app_name = 'agent'
urlpatterns = [
    # 日工资结算[方案]
    path('salaryIndex', SalaryView.as_view(), name='salary'),
    path('addSalary', AddSalaryView.as_view(), name='addSalary'),
    path('msdSalary', MdfSalaryView.as_view(), name='mdfSalary'),
    path('delSalary', DelSalaryView.as_view(), name='delSalary'),
    # 日佣金结算[方案]
    path('commission', CommissionView.as_view(), name='commission'),
    path('addCommission', AddCommissionView.as_view(), name='addCommission'),
    path('mdfCommission', MdfCommissionView.as_view(), name='mdfCommission'),
    path('delCommission', DelCommissionView.as_view(), name='delCommission'),
    # 排行配置
    path('rankConfig', RankConfigView.as_view(), name='rankConfig'),
    path('dayRank', DayRankView.as_view(), name='dayRank'),
    path('monthRank', MonthRankView.as_view(), name='monthRank'),
    path('dayRankDownload', DayRankDownloadView.as_view(), name='dayRankDownload'),
    path('monthRankDownload', MonthRankDownloadView.as_view(), name='monthRankDownload'),
    # 日佣金管理[记录]
    path('dayCommission', DayCommissionView.as_view(), name='dayCommission'),
    path('delDayCommission', DelDayCommissionView.as_view(), name='delDayCommission'),
    path('mdfDayCommission', MdfDayCommissionView.as_view(), name='mdfDayCommission'),
    path('addDayCommission', AddDayCommissionView.as_view(), name='addDayCommission'),
    path('importExcel', ImportExcelView.as_view(), name='importExcel'),
    path('send', SendView.as_view(), name='send'),
    path('batchSend', BatchSendView.as_view(), name='batchSend'),
    path('batchDelete', BatchDeleteView.as_view(), name='batchDelete'),
    path('deleteAll', DeleteAllView.as_view(), name='deleteAll'),
    path('calculation', CalculationView.as_view(), name='calculation'),
    path('downloadDataBefore', DownloadDataBeforeView.as_view(), name='downloadDataBefore'),
    path('downloadData', DownloadDataView.as_view(), name='downloadData'),
    # 月佣金管理[记录]
    path('monthCommission', MonthCommissionView.as_view(), name='monthCommission'),
    path('delMonthCommission', DelMonthCommissionView.as_view(), name='delMonthCommission'),
    path('mdfMonthCommission', MdfMonthCommissionView.as_view(), name='mdfMonthCommission'),
    path('addMonthCommission', AddMonthCommission.as_view(), name='addMonthCommission'),
    path('importMonthExcel', ImportMonthExcelView.as_view(), name='importMonthExcel'),
    path('sendMonth', SendMonthView.as_view(), name='sendMonth'),
    path('batchSendMonth', BatchSendMonthView.as_view(), name='batchSendMonth'),
    path('batchDeleteMonth', BatchDeleteMonthView.as_view(), name='batchDeleteMonth'),
    path('deleteAllMonth', DeleteAllMonthView.as_view(), name='deleteAllMonth'),
    path('downloadDataMonthBefore', DownloadDataMonthBeforeView.as_view(), name='downloadDataMonthBefore'),
    path('downloadDataMonth', DownloadDataMonthView.as_view(), name='downloadDataMonth'),
    # 修改结算方式申请
    path('applicationData', ApplicationDataView.as_view(), name='applicationData'),
    path('applicationDel', ApplicationDelView.as_view(), name='applicationDel'),
    path('passd', PassdView.as_view(), name='passd'),
    path('refused', RefusedView.as_view(), name='refused'),
]
