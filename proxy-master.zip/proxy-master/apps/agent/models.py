from django.db import models


class DayCommission(models.Model):
    """日佣金管理表"""
    user_name = models.CharField('代理账号', max_length=225, db_index=True, default='')
    member_number = models.IntegerField('会员人数', default=0)
    betting_amount = models.BigIntegerField('有效投注', default=0)
    bonus = models.IntegerField('奖金', default=0)
    submit_time = models.CharField('提交时间', max_length=255, default=0)
    agent_url = models.CharField('专属链接', max_length=255, default='')
    commission = models.IntegerField('日佣金', default=0)
    compute_status = models.BooleanField('计算状态', default=False)
    status = models.BooleanField('派发状态', default=False)


class Month_Commission(models.Model):
    """月佣金表"""

    user_name = models.CharField('代理账号', db_index=True, max_length=255)
    commission = models.IntegerField('月佣金', default=0)
    submit_time = models.CharField('提交时间', max_length=255)
    agent_url = models.CharField('专属链接', max_length=255)
    status = models.BooleanField('派发状态', default=False)


class RankingListConfig(models.Model):
    """排行榜配置"""
    day_rank_number = models.SmallIntegerField('日排行个数', default=100)
    month_rank_number = models.SmallIntegerField('月排行个数', default=100)


class Commission(models.Model):
    """日佣金结算方案表"""
    betting_amount = models.IntegerField('日有效投注', db_index=True, default=0)
    member_number = models.IntegerField('日活跃会员', db_index=True, default=0)
    percent = models.DecimalField('日佣金比例', max_digits=5, decimal_places=2, db_index=True, default=0)


class Salary(models.Model):
    """日工资结算方案表"""
    betting_amount = models.IntegerField('日有效投注', db_index=True, default=0)
    salary = models.IntegerField('日工资', default=0)


class Apply(models.Model):
    """申请修改结算方式表"""
    user_name = models.CharField('代理账号', max_length=255)
    status = models.PositiveSmallIntegerField('审核状态', choices=((0, '待审核'), (1, '已通过'), (2, '未通过')), default=0)


# class Domain(models.Model):
#     """网址表"""
#     domain = models.CharField('域名', max_length=255, unique=True, default='')
