/*
 * 表单验证扩展
 * --Made by Luyao
 */
// 手机号验证方法
$.validator.addMethod('isMobile',function(value,element){
	var mobile = /^1[3|5|7|8]\d{9}$/;
	return this.optional(element) || (mobile.test(value)); // optional方法不为空时才进行认证
},'手机号格式错误！');
// QQ号验证
$.validator.addMethod('isQq',function(value,element){
	var qq = /^[1-9][0-9]{4,}$/;
	return this.optional(element) || (qq.test(value)); // optional方法不为空时才进行认证
},'QQ号格式错误！');
// 字母数字验证
$.validator.addMethod('isApp',function(value,element){
	var app = /^[A-Za-z0-9]+$/;
	return this.optional(element) || (app.test(value)); // optional方法不为空时才进行认证
},'格式错误！');
/*
 * 用户名验证，字母数字下划线汉字
 * 汉字：[\u4e00-\u9fa5]
 */
$.validator.addMethod('isUser',function(value,element){
	var user = /^[\w\u4e00-\u9fa5]+$/;
	return this.optional(element) || (user.test(value)); // optional方法不为空时才进行认证
},'格式错误！');