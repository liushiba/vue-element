-- MySQL dump 10.13  Distrib 5.7.30, for Linux (x86_64)
--
-- Host: localhost    Database: hb
-- ------------------------------------------------------
-- Server version	5.7.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can add permission',2,'add_permission'),(5,'Can change permission',2,'change_permission'),(6,'Can delete permission',2,'delete_permission'),(7,'Can add group',3,'add_group'),(8,'Can change group',3,'change_group'),(9,'Can delete group',3,'delete_group'),(10,'Can add content type',4,'add_contenttype'),(11,'Can change content type',4,'change_contenttype'),(12,'Can delete content type',4,'delete_contenttype'),(13,'Can add session',5,'add_session'),(14,'Can change session',5,'change_session'),(15,'Can delete session',5,'delete_session'),(16,'Can add user',6,'add_siteadmin'),(17,'Can change user',6,'change_siteadmin'),(18,'Can delete user',6,'delete_siteadmin'),(19,'Can add info',7,'add_info'),(20,'Can change info',7,'change_info'),(21,'Can delete info',7,'delete_info'),(22,'Can add 奖品管理',8,'add_prize'),(23,'Can change 奖品管理',8,'change_prize'),(24,'Can delete 奖品管理',8,'delete_prize'),(25,'Can add 活动记录',9,'add_rec'),(26,'Can change 活动记录',9,'change_rec'),(27,'Can delete 活动记录',9,'delete_rec'),(28,'Can add 用户设定',10,'add_rule'),(29,'Can change 用户设定',10,'change_rule'),(30,'Can delete 用户设定',10,'delete_rule');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_main_siteadmin_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_main_siteadmin_id` FOREIGN KEY (`user_id`) REFERENCES `main_siteadmin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'contenttypes','contenttype'),(7,'main','info'),(8,'main','prize'),(9,'main','rec'),(10,'main','rule'),(6,'main','siteadmin'),(5,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2019-05-17 09:01:53'),(2,'contenttypes','0002_remove_content_type_name','2019-05-17 09:01:54'),(3,'auth','0001_initial','2019-05-17 09:01:55'),(4,'auth','0002_alter_permission_name_max_length','2019-05-17 09:01:55'),(5,'auth','0003_alter_user_email_max_length','2019-05-17 09:01:56'),(6,'auth','0004_alter_user_username_opts','2019-05-17 09:01:56'),(7,'auth','0005_alter_user_last_login_null','2019-05-17 09:01:56'),(8,'auth','0006_require_contenttypes_0002','2019-05-17 09:01:56'),(9,'auth','0007_alter_validators_add_error_messages','2019-05-17 09:01:56'),(10,'auth','0008_alter_user_username_max_length','2019-05-17 09:01:56'),(11,'main','0001_initial','2019-05-17 09:01:58'),(12,'admin','0001_initial','2019-05-17 09:01:59'),(13,'admin','0002_logentry_remove_auto_add','2019-05-17 09:01:59'),(14,'main','0002_siteadmin_role','2019-05-17 09:01:59'),(15,'main','0003_auto_20190422_1500','2019-05-17 09:02:00'),(16,'sessions','0001_initial','2019-05-17 09:02:00');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `main_info`
--

DROP TABLE IF EXISTS `main_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `is_open` tinyint(1) NOT NULL,
  `errmsg` varchar(100) NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `day_end` time DEFAULT NULL,
  `day_start` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_info`
--

LOCK TABLES `main_info` WRITE;
/*!40000 ALTER TABLE `main_info` DISABLE KEYS */;
INSERT INTO `main_info` VALUES (1,'白羊座红包',1,'活动还未开启','2020-06-08 04:00:00','2021-12-30 04:00:00','23:59:59','00:00:00');
/*!40000 ALTER TABLE `main_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `main_prize`
--

DROP TABLE IF EXISTS `main_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_prize` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) NOT NULL,
  `prize_name` varchar(64) NOT NULL,
  `probability` int(11) NOT NULL,
  `grade` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_prize`
--

LOCK TABLES `main_prize` WRITE;
/*!40000 ALTER TABLE `main_prize` DISABLE KEYS */;
INSERT INTO `main_prize` VALUES (10,1,'祝您好运,再接再厉',10,'默认'),(16,1,'祝您好运，再接再厉',70,'刷水'),(17,2,'\"现金筹码0.8~3元\"',20,'刷水'),(18,3,'\"现金筹码4.8~10元\"',10,'刷水'),(19,4,'\"现金筹码38~188元\"',0,'刷水'),(35,1,'祝您好运,再接再厉',10,'红包雨'),(36,2,'\"现金筹码0~0.9元\"',12,'红包雨'),(37,3,'\"现金筹码1~1.8元\"',15,'红包雨'),(38,4,'\"现金筹码2~5.8元\"',18,'红包雨'),(39,5,'\"现金筹码5.8~6元\"',15,'红包雨'),(40,6,'\"现金筹码6.8~9元\"',10,'红包雨'),(41,7,'\"现金筹码10.8~18元\"',10,'红包雨'),(42,8,'\"现金筹码19.8~26元\"',7,'红包雨'),(43,9,'\"现金筹码28.8~38元\"',3,'红包雨'),(44,2,'\"现金筹码1~2元\"',12,'默认'),(45,3,'\"现金筹码1.8~3元\"',15,'默认'),(46,4,'\"现金筹码2.8~6元\"',17,'默认'),(47,5,'\"现金筹码6.8~7元\"',16,'默认'),(48,6,'\"现金筹码7~9.8元\"',12,'默认'),(49,7,'\"现金筹码10.8~18元\"',10,'默认'),(50,8,'\"现金筹码19.8~26元\"',6,'默认'),(51,9,'\"现金筹码28.8~38元\"',2,'默认');
/*!40000 ALTER TABLE `main_prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `main_rec`
--

DROP TABLE IF EXISTS `main_rec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_rec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(32) NOT NULL,
  `prizeName` varchar(64) NOT NULL,
  `prizeId` int(11) DEFAULT NULL,
  `datetime` datetime NOT NULL,
  `sendTime` datetime DEFAULT NULL,
  `isSend` int(11) NOT NULL,
  `censor` varchar(32) DEFAULT NULL,
  `ip` char(39) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66090 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_rec`
--

LOCK TABLES `main_rec` WRITE;
/*!40000 ALTER TABLE `main_rec` DISABLE KEYS */;
INSERT INTO `main_rec` VALUES (66032,'ljp19970907','祝您好运,再接再厉',1,'2020-12-26 04:36:14','2020-12-26 04:37:22',1,'hongbao','172.68.132.92',0),(66033,'a13797070099','\"现金筹码28.21元\"',9,'2020-12-26 04:52:05','2020-12-26 04:53:56',1,'hongbao','162.158.255.253',0),(66034,'a13797070099','\"现金筹码1元\"',2,'2020-12-26 04:52:09','2020-12-26 04:54:14',1,'hongbao','162.158.255.253',0),(66035,'15096810860m','\"现金筹码1元\"',2,'2020-12-26 04:54:22','2020-12-26 04:57:37',1,'hongbao','108.162.215.113',0),(66036,'15096810860m','\"现金筹码1.4元\"',3,'2020-12-26 04:54:30','2020-12-26 04:57:51',1,'hongbao','108.162.215.113',0),(66037,'mingli56789','\"现金筹码19.21元\"',8,'2020-12-26 05:00:48','2020-12-26 05:01:53',1,'hongbao','172.68.141.167',0),(66038,'mingli56789','\"现金筹码1元\"',2,'2020-12-26 05:01:34','2020-12-26 05:02:09',1,'hongbao','172.68.141.167',0),(66039,'mingli56789','\"现金筹码1.7元\"',3,'2020-12-26 05:01:34','2020-12-26 05:02:25',1,'hongbao','172.68.141.167',0),(66040,'mingli56789','\"现金筹码6.7元\"',5,'2020-12-26 05:01:40','2020-12-26 05:02:42',1,'hongbao','172.68.141.167',0),(66041,'mingli56789','\"现金筹码1元\"',2,'2020-12-26 05:01:41','2020-12-26 05:02:56',1,'hongbao','172.68.141.167',0),(66042,'lianshenh','\"现金筹码1.6元\"',3,'2020-12-26 05:09:43','2020-12-26 05:11:44',1,'hongbao','172.68.132.46',0),(66043,'lianshenh','\"现金筹码1.7元\"',3,'2020-12-26 05:09:46','2020-12-26 05:11:56',1,'hongbao','172.68.132.46',0),(66044,'lianshenh','\"现金筹码1.7元\"',3,'2020-12-26 05:09:50','2020-12-26 05:12:13',1,'hongbao','172.68.132.46',0),(66045,'zcj777','\"现金筹码7.8元\"',6,'2020-12-26 05:18:27','2020-12-26 05:31:12',1,'hongbao','172.69.33.68',0),(66046,'dyf198183','\"现金筹码1.5元\"',3,'2020-12-26 05:24:28','2020-12-26 05:31:31',1,'hongbao','172.68.133.17',0),(66047,'dyf198183','\"现金筹码2.6元\"',4,'2020-12-26 05:24:33','2020-12-26 05:31:48',1,'hongbao','172.68.133.17',0),(66048,'xbs1022','\"现金筹码1.4元\"',3,'2020-12-26 05:27:18','2020-12-26 05:32:03',1,'hongbao','172.69.35.16',0),(66049,'txr7726','\"现金筹码10.14元\"',7,'2020-12-26 05:30:19','2020-12-26 05:32:19',1,'hongbao','172.69.22.39',0),(66050,'cjp123456','\"现金筹码8.8元\"',6,'2020-12-26 05:46:55','2020-12-26 05:49:13',1,'hongbao','172.69.33.68',0),(66051,'cjp123456','\"现金筹码1元\"',2,'2020-12-26 05:47:03','2020-12-26 05:49:28',1,'hongbao','172.69.33.168',0),(66052,'cjp123456','\"现金筹码2.7元\"',4,'2020-12-26 05:47:03','2020-12-26 05:49:46',1,'hongbao','172.69.34.5',0),(66053,'daishu222','\"现金筹码1元\"',2,'2020-12-26 05:47:31','2020-12-26 05:50:24',1,'hongbao','172.69.33.68',0),(66054,'daishu222','\"现金筹码6.7元\"',5,'2020-12-26 05:47:34','2020-12-26 05:50:39',1,'hongbao','172.69.33.68',0),(66055,'maoer888','\"现金筹码10.13元\"',7,'2020-12-26 05:47:59','2020-12-26 05:50:51',1,'hongbao','172.69.33.68',0),(66056,'maoer888','\"现金筹码2.6元\"',4,'2020-12-26 05:48:02','2020-12-26 05:51:04',1,'hongbao','172.69.33.68',0),(66057,'maoer888','\"现金筹码6.7元\"',5,'2020-12-26 05:48:06','2020-12-26 05:51:18',1,'hongbao','172.69.33.68',0),(66058,'cyp527888','\"现金筹码2.6元\"',4,'2020-12-26 06:14:01','2020-12-26 06:15:54',1,'hongbao','172.68.133.17',0),(66059,'yu198516','\"现金筹码10.17元\"',7,'2020-12-26 06:24:51','2020-12-26 06:25:18',1,'hongbao','172.69.33.92',0),(66060,'zaiwanwan','\"现金筹码2.6元\"',4,'2020-12-26 06:36:16','2020-12-26 06:37:56',1,'hongbao','108.162.215.113',0),(66061,'zaiwanwan','\"现金筹码1.6元\"',3,'2020-12-26 06:36:20','2020-12-26 06:38:11',1,'hongbao','108.162.215.113',0),(66062,'cy520520','祝您好运,再接再厉',1,'2020-12-26 07:03:04','2020-12-26 07:04:29',1,'hongbao','172.68.132.92',0),(66063,'cy520520','祝您好运,再接再厉',1,'2020-12-26 07:03:12','2020-12-26 07:04:29',1,'hongbao','172.68.132.92',0),(66064,'12394304568','\"现金筹码1元\"',2,'2020-12-26 07:15:33','2020-12-26 07:16:56',1,'hongbao','172.69.33.126',0),(66065,'12394304568','祝您好运,再接再厉',1,'2020-12-26 07:15:39','2020-12-26 07:16:57',1,'hongbao','172.69.34.167',0),(66066,'a2394304568','\"现金筹码1元\"',2,'2020-12-26 07:15:58','2020-12-26 07:17:11',1,'hongbao','108.162.215.49',0),(66067,'tt0115','祝您好运,再接再厉',1,'2020-12-26 07:21:22','2020-12-26 07:25:28',1,'hongbao','172.69.227.135',0),(66068,'tt0115','\"现金筹码1元\"',2,'2020-12-26 07:21:25','2020-12-26 07:25:44',1,'hongbao','172.69.227.135',0),(66069,'nasai88','\"现金筹码2.6元\"',4,'2020-12-26 07:35:36','2020-12-26 07:35:57',1,'hongbao','172.69.34.167',0),(66070,'nasai88','\"现金筹码10.16元\"',7,'2020-12-26 07:35:46','2020-12-26 07:36:08',1,'hongbao','172.69.34.167',0),(66071,'niwen888','\"现金筹码1.3元\"',3,'2020-12-26 07:41:22','2020-12-26 07:42:29',1,'hongbao','172.69.34.5',0),(66072,'y701013','祝您好运,再接再厉',1,'2020-12-26 07:43:45','2020-12-26 07:43:52',1,'hongbao','108.162.215.113',0),(66073,'y701013','\"现金筹码1元\"',2,'2020-12-26 07:43:52','2020-12-26 07:44:09',1,'hongbao','108.162.215.113',0),(66074,'EEH6688','\"现金筹码1.3元\"',3,'2020-12-26 08:11:53','2020-12-26 08:12:48',1,'hongbao','172.69.34.167',0),(66075,'EEH6688','\"现金筹码7.8元\"',6,'2020-12-26 08:12:01','2020-12-26 08:12:59',1,'hongbao','172.69.34.167',0),(66076,'EEH6688','祝您好运,再接再厉',1,'2020-12-26 08:12:17','2020-12-26 08:13:01',1,'hongbao','172.69.34.167',0),(66077,'yao993399','\"现金筹码6.7元\"',5,'2020-12-26 09:11:48','2020-12-26 09:23:19',1,'hongbao','108.162.215.13',0),(66078,'yao993399','祝您好运,再接再厉',1,'2020-12-26 09:11:52','2020-12-26 09:23:22',1,'hongbao','108.162.215.13',0),(66079,'qc131415','\"现金筹码6.7元\"',5,'2020-12-26 09:18:09','2020-12-26 09:23:37',1,'hongbao','108.162.215.49',0),(66080,'zl391','\"现金筹码2.6元\"',4,'2020-12-26 12:25:51','2020-12-26 12:33:04',1,'hongbao','108.162.215.29',0),(66081,'zl391','\"现金筹码1.7元\"',3,'2020-12-26 12:25:52','2020-12-26 12:38:46',1,'hongbao','108.162.215.29',0),(66082,'swj9971','\"现金筹码1元\"',2,'2020-12-26 12:27:01','2020-12-26 12:39:03',1,'hongbao','172.69.33.124',0),(66083,'hsp666','\"现金筹码8.8元\"',6,'2020-12-26 12:33:41','2020-12-26 12:39:18',1,'hongbao','172.69.33.92',0),(66084,'hc156825','\"现金筹码19.17元\"',8,'2020-12-26 12:33:55','2020-12-26 12:39:30',1,'hongbao','172.69.33.92',0),(66085,'hc156825','\"现金筹码1.4元\"',3,'2020-12-26 12:33:59','2020-12-26 12:39:44',1,'hongbao','172.69.33.92',0),(66086,'hsp8888','祝您好运,再接再厉',1,'2020-12-26 12:34:14','2020-12-26 12:39:48',1,'hongbao','172.69.33.92',0),(66087,'hsp8888','祝您好运,再接再厉',1,'2020-12-26 12:34:14','2020-12-26 12:39:49',1,'hongbao','172.69.33.92',0),(66088,'hsp8888','\"现金筹码1.3元\"',3,'2020-12-26 12:34:14','2020-12-26 12:40:07',1,'hongbao','172.69.33.92',0),(66089,'hhhhcc','\"现金筹码6.7元\"',5,'2020-12-26 13:36:57','2020-12-26 13:39:17',1,'hongbao','172.68.133.17',0);
/*!40000 ALTER TABLE `main_rec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `main_rule`
--

DROP TABLE IF EXISTS `main_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(32) NOT NULL,
  `sequence` varchar(64) NOT NULL,
  `flag` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `addTime` datetime NOT NULL,
  `type` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=269016 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_rule`
--

LOCK TABLES `main_rule` WRITE;
/*!40000 ALTER TABLE `main_rule` DISABLE KEYS */;
INSERT INTO `main_rule` VALUES (268769,'qkh123456','?',1,1,'2020-12-26 04:35:16','默认'),(268770,'lsk888','?',1,1,'2020-12-26 04:35:16','默认'),(268771,'zzh125868','?',1,1,'2020-12-26 04:35:16','默认'),(268772,'chen19850101','?',1,1,'2020-12-26 04:35:16','默认'),(268773,'zy1898836707','?',1,1,'2020-12-26 04:35:16','默认'),(268774,'18608866968','?',1,1,'2020-12-26 04:35:16','默认'),(268775,'w15940750231','?',1,1,'2020-12-26 04:35:16','默认'),(268776,'lxj1998','?',1,1,'2020-12-26 04:35:16','默认'),(268777,'ht123456','?',1,1,'2020-12-26 04:35:16','默认'),(268778,'18077155170','?',1,1,'2020-12-26 04:35:16','默认'),(268779,'18487595650','?',1,1,'2020-12-26 04:35:16','默认'),(268780,'zhangsan666','?',1,1,'2020-12-26 04:35:16','默认'),(268781,'qwe886','?',1,1,'2020-12-26 04:35:16','默认'),(268782,'tcc5381','?',1,1,'2020-12-26 04:35:16','默认'),(268783,'yq00000','?',1,1,'2020-12-26 04:35:16','默认'),(268784,'zhu1995','?',1,1,'2020-12-26 04:35:16','默认'),(268785,'153290595','?',1,1,'2020-12-26 04:35:16','默认'),(268786,'shetao0123','?',1,1,'2020-12-26 04:35:16','默认'),(268787,'gwq1994','?',1,1,'2020-12-26 04:35:16','默认'),(268788,'88884444','?',1,1,'2020-12-26 04:35:16','默认'),(268789,'hwq8888','?',1,1,'2020-12-26 04:35:16','默认'),(268790,'15926817247','?',1,1,'2020-12-26 04:35:16','默认'),(268791,'o19940712','?',1,1,'2020-12-26 04:35:16','默认'),(268792,'ao999888777','?',1,1,'2020-12-26 04:35:16','默认'),(268793,'qyh123236','?',1,1,'2020-12-26 04:35:16','默认'),(268794,'lb1119','?',1,1,'2020-12-26 04:35:16','默认'),(268795,'zt8498','?',1,1,'2020-12-26 04:35:16','默认'),(268796,'hjzs666','?',1,1,'2020-12-26 04:35:16','默认'),(268797,'shz12399','?',1,1,'2020-12-26 04:35:16','默认'),(268798,'kele0804','?',1,1,'2020-12-26 04:35:16','默认'),(268799,'swj9971','?',2,0,'2020-12-26 04:35:16','默认'),(268800,'sxl7079','?',1,1,'2020-12-26 04:35:16','默认'),(268801,'1213140','?',1,1,'2020-12-26 04:35:16','默认'),(268802,'ssw19940','?',1,1,'2020-12-26 04:35:16','默认'),(268803,'wanglele96','?',1,1,'2020-12-26 04:35:16','默认'),(268804,'zj12399','?',1,1,'2020-12-26 04:35:16','默认'),(268805,'zj4248','?',1,1,'2020-12-26 04:35:16','默认'),(268806,'lm9877','?',1,1,'2020-12-26 04:35:16','默认'),(268807,'sgj1997','?',1,1,'2020-12-26 04:35:16','默认'),(268808,'syy1994','?',1,1,'2020-12-26 04:35:16','默认'),(268809,'ym952843852','?',1,1,'2020-12-26 04:35:16','默认'),(268810,'xbs1022','?',2,0,'2020-12-26 04:35:16','默认'),(268811,'1931199639','?',1,1,'2020-12-26 04:35:16','默认'),(268812,'amber','?',1,1,'2020-12-26 04:35:16','默认'),(268813,'a7283330','?',1,1,'2020-12-26 04:35:16','默认'),(268814,'yx26671','?',1,1,'2020-12-26 04:35:16','默认'),(268815,'baidu9893','?',1,1,'2020-12-26 04:35:16','默认'),(268816,'zyz8070','?',1,1,'2020-12-26 04:35:16','默认'),(268817,'fhc138168','?',1,1,'2020-12-26 04:35:16','默认'),(268818,'18214582044','?',1,1,'2020-12-26 04:35:16','默认'),(268819,'ljp19970907','?',2,0,'2020-12-26 04:35:16','默认'),(268820,'nbjj1996','?',1,1,'2020-12-26 04:35:16','默认'),(268821,'13388867927','?',1,1,'2020-12-26 04:35:16','默认'),(268822,'684002','?',1,1,'2020-12-26 04:35:16','默认'),(268823,'dsfdhg','?',1,1,'2020-12-26 04:35:16','默认'),(268824,'hh110110hh','?',1,1,'2020-12-26 04:35:16','默认'),(268825,'ken1987','?',1,1,'2020-12-26 04:35:16','默认'),(268826,'plmoknijb123','?',1,1,'2020-12-26 04:35:16','默认'),(268827,'138423','?',1,1,'2020-12-26 04:35:16','默认'),(268828,'ldc888888','?',1,1,'2020-12-26 04:35:16','默认'),(268829,'123ysw','?',1,1,'2020-12-26 04:35:16','默认'),(268830,'xue2646','?',1,1,'2020-12-26 04:35:16','默认'),(268831,'yyz123','?',1,1,'2020-12-26 04:35:16','默认'),(268832,'q5674146','?',1,1,'2020-12-26 04:35:16','默认'),(268833,'caoyaqian199','?',1,1,'2020-12-26 04:35:16','默认'),(268834,'ytq123','?',1,1,'2020-12-26 04:35:16','默认'),(268835,'caoying0707','?',1,1,'2020-12-26 04:35:16','默认'),(268836,'limin678','?',1,1,'2020-12-26 04:35:16','默认'),(268837,'yq881','?',1,1,'2020-12-26 04:35:16','默认'),(268838,'cp78818','?',1,1,'2020-12-26 04:35:16','默认'),(268839,'lxc7788','?',1,1,'2020-12-26 04:35:16','默认'),(268840,'960966604','?',1,1,'2020-12-26 04:35:16','默认'),(268841,'zxcv8888','?',1,1,'2020-12-26 04:35:16','默认'),(268842,'ch8523','?',1,1,'2020-12-26 04:35:16','默认'),(268843,'xiang8888','?',1,1,'2020-12-26 04:35:16','默认'),(268844,'qs7737','?',1,1,'2020-12-26 04:35:16','默认'),(268845,'yyh123','?',1,1,'2020-12-26 04:35:16','默认'),(268846,'gwx1994','?',1,1,'2020-12-26 04:35:16','默认'),(268847,'hj7738','?',1,1,'2020-12-26 04:35:16','默认'),(268848,'yxn5888','?',1,1,'2020-12-26 04:35:16','默认'),(268849,'gch12399','?',1,1,'2020-12-26 04:35:16','默认'),(268850,'dehong777','?',1,1,'2020-12-26 04:35:16','默认'),(268851,'hhhhcc','?',2,0,'2020-12-26 04:35:16','默认'),(268852,'cyf70204','?',1,1,'2020-12-26 04:35:16','默认'),(268853,'lc6666','?',1,1,'2020-12-26 04:35:16','默认'),(268854,'199751lrc','?',1,1,'2020-12-26 04:35:16','默认'),(268855,'xlp10086','?',1,1,'2020-12-26 04:35:16','默认'),(268856,'qq8162546','?',1,1,'2020-12-26 04:35:16','默认'),(268857,'a2394304568','?',2,0,'2020-12-26 04:35:16','默认'),(268858,'qc131415','?',2,0,'2020-12-26 04:35:16','默认'),(268859,'a784825791','?',1,1,'2020-12-26 04:35:16','默认'),(268860,'qwe123124','?',1,1,'2020-12-26 04:35:16','默认'),(268861,'qq698848','?',1,1,'2020-12-26 04:35:16','默认'),(268862,'niwen888','?',2,0,'2020-12-26 04:35:16','默认'),(268863,'lsy5201314','?',1,1,'2020-12-26 04:35:16','默认'),(268864,'yuan653182','?',1,1,'2020-12-26 04:35:16','默认'),(268865,'wd123lch','?',1,1,'2020-12-26 04:35:16','默认'),(268866,'xiaodao18708','?',1,1,'2020-12-26 04:35:16','默认'),(268867,'yzd1234','?',1,1,'2020-12-26 04:35:16','默认'),(268868,'wangyeqi','?',1,1,'2020-12-26 04:35:16','默认'),(268869,'yxsh1968','?',1,1,'2020-12-26 04:35:16','默认'),(268870,'abc1510177','?',1,1,'2020-12-26 04:35:16','默认'),(268871,'lixiang','?',1,1,'2020-12-26 04:35:16','默认'),(268872,'pp5187777','?',1,1,'2020-12-26 04:35:16','默认'),(268873,'aomen1314','?',1,1,'2020-12-26 04:35:16','默认'),(268874,'yuzhiqing88','?',1,1,'2020-12-26 04:35:16','默认'),(268875,'xiangzuokun1','?',1,1,'2020-12-26 04:35:16','默认'),(268876,'hall9909','?',1,1,'2020-12-26 04:35:16','默认'),(268877,'hojin8888','?',1,1,'2020-12-26 04:35:16','默认'),(268878,'ljhljylhy','?',1,1,'2020-12-26 04:35:16','默认'),(268879,'pdj123','?',1,1,'2020-12-26 04:35:16','默认'),(268880,'hql8899','?',1,1,'2020-12-26 04:35:16','默认'),(268881,'njcc120','?',1,1,'2020-12-26 04:35:16','默认'),(268882,'hsp666','?',2,0,'2020-12-26 04:35:16','默认'),(268883,'1880698','?',1,1,'2020-12-26 04:35:16','默认'),(268884,'123456654','?',1,1,'2020-12-26 04:35:16','默认'),(268885,'plplpl999','?',1,1,'2020-12-26 04:35:16','默认'),(268886,'13250806616','?',1,1,'2020-12-26 04:35:16','默认'),(268887,'liyifei520','?',1,1,'2020-12-26 04:35:16','默认'),(268888,'wdx67777','?',1,1,'2020-12-26 04:35:16','默认'),(268889,'280203aq','?',1,1,'2020-12-26 04:35:16','默认'),(268890,'13378860577','?',1,1,'2020-12-26 04:35:16','默认'),(268891,'jzw085','?',1,1,'2020-12-26 04:35:16','默认'),(268892,'baihu521','?',1,1,'2020-12-26 04:35:16','默认'),(268893,'22296181','?',1,1,'2020-12-26 04:35:16','默认'),(268894,'bing1234567','?',1,1,'2020-12-26 04:35:16','默认'),(268895,'9877','?',1,1,'2020-12-26 04:35:16','默认'),(268896,'huzhencan123','?',1,1,'2020-12-26 04:35:16','默认'),(268897,'xieyi9159384','?',1,1,'2020-12-26 04:35:16','默认'),(268898,'g15140766234','?',1,1,'2020-12-26 04:35:16','默认'),(268899,'han4321','?',1,1,'2020-12-26 04:35:16','默认'),(268900,'yeoicq','?',1,1,'2020-12-26 04:35:16','默认'),(268901,'zcj777','?',2,0,'2020-12-26 04:35:16','默认'),(268902,'wzh1868852','?',1,1,'2020-12-26 04:35:16','默认'),(268903,'yu198516','?',2,0,'2020-12-26 04:35:16','默认'),(268904,'aiyun7726','?',1,1,'2020-12-26 04:35:16','默认'),(268905,'15808654552','?',1,1,'2020-12-26 04:35:16','默认'),(268906,'xxx1516xxx','?',1,1,'2020-12-26 04:35:16','默认'),(268907,'153025171','?',1,1,'2020-12-26 04:35:16','默认'),(268908,'a13988661995','?',1,1,'2020-12-26 04:35:16','默认'),(268909,'c18776017602','?',1,1,'2020-12-26 04:35:16','默认'),(268910,'jiajun01','?',1,1,'2020-12-26 04:35:16','默认'),(268911,'dyr5678','?',1,1,'2020-12-26 04:35:16','默认'),(268912,'txr7726','?',2,0,'2020-12-26 04:35:16','默认'),(268913,'hjq53210','?',1,1,'2020-12-26 04:35:16','默认'),(268914,'zjx520520','?',1,1,'2020-12-26 04:35:16','默认'),(268915,'cyp527888','?',2,0,'2020-12-26 04:35:16','默认'),(268916,'aybb100','?',1,1,'2020-12-26 04:35:16','默认'),(268917,'tanghao1','?',1,1,'2020-12-26 04:35:16','默认'),(268918,'vcdd223','?',1,1,'2020-12-26 04:35:16','默认'),(268919,'rtrdyjhgk6','?',1,1,'2020-12-26 04:35:16','默认'),(268920,'mm2019','?',1,1,'2020-12-26 04:35:16','默认'),(268921,'aaa369963','?',1,1,'2020-12-26 04:35:16','默认'),(268922,'yx2326039921','?',1,1,'2020-12-26 04:35:16','默认'),(268923,'xyt123','?',1,1,'2020-12-26 04:35:16','默认'),(268924,'zxw226789','?',1,1,'2020-12-26 04:35:16','默认'),(268925,'18213137258','?',1,1,'2020-12-26 04:35:16','默认'),(268926,'ccbawmq','?',1,1,'2020-12-26 04:35:16','默认'),(268927,'qq121648','?',1,1,'2020-12-26 04:35:16','默认'),(268928,'pdj2023','?',1,1,'2020-12-26 04:35:16','默认'),(268929,'ysh168888','?',1,1,'2020-12-26 04:35:16','默认'),(268930,'1601846310','?',1,1,'2020-12-26 04:35:16','默认'),(268931,'2843328','?',1,1,'2020-12-26 04:35:16','默认'),(268932,'abc386622','?',1,1,'2020-12-26 04:35:16','默认'),(268933,'shiyang520','?',1,1,'2020-12-26 04:35:16','默认'),(268934,'xiaoben2013','?',1,1,'2020-12-26 04:35:16','默认'),(268935,'147258aq','?',1,1,'2020-12-26 04:35:16','默认'),(268936,'946428266','?',1,1,'2020-12-26 04:35:16','默认'),(268937,'lsh7275','?',1,1,'2020-12-26 04:35:16','默认'),(268938,'yzx0885','?',1,2,'2020-12-26 04:35:16','默认'),(268939,'2020fbc','?',1,2,'2020-12-26 04:35:16','默认'),(268940,'mlm3434','?',1,2,'2020-12-26 04:35:16','默认'),(268941,'5590','?',1,2,'2020-12-26 04:35:16','默认'),(268942,'147258yg0','?',1,2,'2020-12-26 04:35:16','默认'),(268943,'csw16888','?',1,2,'2020-12-26 04:35:16','默认'),(268944,'fxazx2','?',1,2,'2020-12-26 04:35:16','默认'),(268945,'hsp8888','?',2,0,'2020-12-26 04:35:16','默认'),(268946,'liu741852','?',1,2,'2020-12-26 04:35:16','默认'),(268947,'ruirui123','?',1,2,'2020-12-26 04:35:16','默认'),(268948,'tt0115','?',2,0,'2020-12-26 04:35:16','默认'),(268949,'dyf198183','?',2,0,'2020-12-26 04:35:16','默认'),(268950,'yuyu8585','?',1,2,'2020-12-26 04:35:16','默认'),(268951,'616410177','?',1,2,'2020-12-26 04:35:16','默认'),(268952,'wei159712274','?',1,2,'2020-12-26 04:35:16','默认'),(268953,'ygw12345678','?',1,2,'2020-12-26 04:35:16','默认'),(268954,'12394304568','?',2,0,'2020-12-26 04:35:16','默认'),(268955,'lsw19920309','?',1,2,'2020-12-26 04:35:16','默认'),(268956,'sy051968','?',1,2,'2020-12-26 04:35:16','默认'),(268957,'zjw52752','?',1,2,'2020-12-26 04:35:16','默认'),(268958,'62236ll','?',1,2,'2020-12-26 04:35:16','默认'),(268959,'18806980153','?',1,2,'2020-12-26 04:35:16','默认'),(268960,'1461832510','?',1,2,'2020-12-26 04:35:16','默认'),(268961,'ljj888888','?',1,2,'2020-12-26 04:35:16','默认'),(268962,'vmy896','?',1,2,'2020-12-26 04:35:16','默认'),(268963,'ligen','?',1,2,'2020-12-26 04:35:16','默认'),(268964,'15096810860m','?',2,0,'2020-12-26 04:35:16','默认'),(268965,'cy520520','?',2,0,'2020-12-26 04:35:16','默认'),(268966,'h1920718501','?',1,2,'2020-12-26 04:35:16','默认'),(268967,'cpf123456','?',1,2,'2020-12-26 04:35:16','默认'),(268968,'zhuguozi','?',1,2,'2020-12-26 04:35:16','默认'),(268969,'zaiwanwan','?',2,0,'2020-12-26 04:35:16','默认'),(268970,'cjp123456','?',2,0,'2020-12-26 04:35:16','默认'),(268971,'ah0063','?',1,2,'2020-12-26 04:35:16','默认'),(268972,'a13797070099','?',2,0,'2020-12-26 04:35:16','默认'),(268973,'cbs888888','?',1,2,'2020-12-26 04:35:16','默认'),(268974,'y701013','?',2,0,'2020-12-26 04:35:16','默认'),(268975,'zl391','?',2,0,'2020-12-26 04:35:16','默认'),(268976,'yujie123456','?',1,2,'2020-12-26 04:35:16','默认'),(268977,'kll1979','?',1,2,'2020-12-26 04:35:16','默认'),(268978,'zx700','?',1,2,'2020-12-26 04:35:16','默认'),(268979,'csn1314520','?',1,2,'2020-12-26 04:35:16','默认'),(268980,'cdqking','?',1,2,'2020-12-26 04:35:16','默认'),(268981,'46769656','?',1,2,'2020-12-26 04:35:16','默认'),(268982,'hc156825','?',2,0,'2020-12-26 04:35:16','默认'),(268983,'nasai88','?',2,0,'2020-12-26 04:35:16','默认'),(268984,'199835ozq','?',1,2,'2020-12-26 04:35:16','默认'),(268985,'luo1989','?',1,2,'2020-12-26 04:35:16','默认'),(268986,'lyx01','?',1,2,'2020-12-26 04:35:16','默认'),(268987,'abc789234','?',1,2,'2020-12-26 04:35:16','默认'),(268988,'c1817237','?',1,2,'2020-12-26 04:35:16','默认'),(268989,'xz123123','?',1,2,'2020-12-26 04:35:16','默认'),(268990,'yao993399','?',2,0,'2020-12-26 04:35:16','默认'),(268991,'aizi19840601','?',1,2,'2020-12-26 04:35:16','默认'),(268992,'x78578664','?',1,2,'2020-12-26 04:35:16','默认'),(268993,'zhukaiwen12','?',1,2,'2020-12-26 04:35:16','默认'),(268994,'daishu222','?',2,0,'2020-12-26 04:35:16','默认'),(268995,'gm77','?',1,2,'2020-12-26 04:35:16','默认'),(268996,'aw12345678','?',1,2,'2020-12-26 04:35:16','默认'),(268997,'z17386678103','?',1,2,'2020-12-26 04:35:16','默认'),(268998,'maoer888','?',2,0,'2020-12-26 04:35:16','默认'),(268999,'gzs9999','?',1,3,'2020-12-26 04:35:16','默认'),(269000,'eeh6688','?',2,0,'2020-12-26 04:35:16','默认'),(269001,'qqaw123456','?',1,3,'2020-12-26 04:35:16','默认'),(269002,'lianshenh','?',2,0,'2020-12-26 04:35:16','默认'),(269003,'xinqingdao12','?',1,3,'2020-12-26 04:35:16','默认'),(269004,'htg1216','?',1,3,'2020-12-26 04:35:16','默认'),(269005,'kun12345','?',1,3,'2020-12-26 04:35:16','默认'),(269006,'hong000','?',1,3,'2020-12-26 04:35:16','默认'),(269007,'cjh888888','?',1,3,'2020-12-26 04:35:16','默认'),(269008,'18988386699','?',1,3,'2020-12-26 04:35:16','默认'),(269009,'caipengfei12','?',1,3,'2020-12-26 04:35:16','默认'),(269010,'man88168','?',1,3,'2020-12-26 04:35:16','默认'),(269011,'mingli56789','?',2,0,'2020-12-26 04:35:16','默认'),(269012,'jianjian1234','?',1,5,'2020-12-26 04:35:16','默认'),(269013,'ctpop12345','?',1,5,'2020-12-26 04:35:16','默认'),(269014,'aa656398438','?',1,5,'2020-12-26 04:35:16','默认'),(269015,'hxl12345','?',1,8,'2020-12-26 04:35:16','默认');
/*!40000 ALTER TABLE `main_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `main_siteadmin`
--

DROP TABLE IF EXISTS `main_siteadmin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_siteadmin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  `role` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_siteadmin`
--

LOCK TABLES `main_siteadmin` WRITE;
/*!40000 ALTER TABLE `main_siteadmin` DISABLE KEYS */;
INSERT INTO `main_siteadmin` VALUES (1,'pbkdf2_sha256$36000$2MZ1KhNFuPyb$sUdmYtUK61vHaeJctkcz53SiKY+eL42walVz+uu+tHE=','2020-12-26 11:52:18',1,'guanli','','','june@163.com',1,1,'2019-05-17 09:02:44','1|2|3|4|5|6'),(2,'pbkdf2_sha256$36000$nSlfTSo05Lqr$jt0dn3H6e97gAzNHRUD42CMOfcdqDz6Li8R4fFalUR0=','2020-12-26 13:52:39',0,'hongbao','','','',1,1,'2019-05-19 02:21:15','5');
/*!40000 ALTER TABLE `main_siteadmin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `main_siteadmin_groups`
--

DROP TABLE IF EXISTS `main_siteadmin_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_siteadmin_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteadmin_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `main_siteadmin_groups_siteadmin_id_group_id_a79cb444_uniq` (`siteadmin_id`,`group_id`),
  KEY `main_siteadmin_groups_group_id_583ed50e_fk_auth_group_id` (`group_id`),
  CONSTRAINT `main_siteadmin_groups_group_id_583ed50e_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `main_siteadmin_groups_siteadmin_id_efbba5d7_fk_main_siteadmin_id` FOREIGN KEY (`siteadmin_id`) REFERENCES `main_siteadmin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_siteadmin_groups`
--

LOCK TABLES `main_siteadmin_groups` WRITE;
/*!40000 ALTER TABLE `main_siteadmin_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `main_siteadmin_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `main_siteadmin_user_permissions`
--

DROP TABLE IF EXISTS `main_siteadmin_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_siteadmin_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteadmin_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `main_siteadmin_user_perm_siteadmin_id_permission__60dff736_uniq` (`siteadmin_id`,`permission_id`),
  KEY `main_siteadmin_user__permission_id_da88ba02_fk_auth_perm` (`permission_id`),
  CONSTRAINT `main_siteadmin_user__permission_id_da88ba02_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `main_siteadmin_user__siteadmin_id_c9ea6b09_fk_main_site` FOREIGN KEY (`siteadmin_id`) REFERENCES `main_siteadmin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_siteadmin_user_permissions`
--

LOCK TABLES `main_siteadmin_user_permissions` WRITE;
/*!40000 ALTER TABLE `main_siteadmin_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `main_siteadmin_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-26 21:53:05
